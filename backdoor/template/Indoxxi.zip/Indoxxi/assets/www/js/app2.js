var _0x550c = ["text", "trim", "toLowerCase", "https://m.akubebas.com/api/featured.php", "substring", "#home-page-list",
        "html",
        '<div id="featured-refresh-btn" style="padding: 8px;text-align: center;border: 1px solid #E7D064;background: #3f3f3f;display:inline-block;margin:auto%;transform: translateX(5%);-webkit-transform: translate(5%);border-radius: 5px;" onclick="getRecommends();"><i class="fa fa-refresh"></i> Muat Ulang</div>',
        "fadeOut", ".page-overlay", "suben_count", '<img src="https://img.akubebas.com/images/US.png"/>', "subid_count",
        '<img src="https://img.akubebas.com/images/ID.png"/>', "type", "quality", "trailer",
        ' style="background:rgba(117,0,214,.8);"', ' style="background:rgba(255, 57, 148, 0.8);"', "blu",
        ' style="background: linear-gradient(#b07b01, #ffec83, #b07b01)!important;color: #191919 !important;font-weight: 800 !important;"',
        "hd_level", ' style="background:rgba(255, 146, 24, .8);"', ' style="background:rgba(11,171,0,.8);"',
        ' style="background:rgba(4,149,212,.8);"', "FHD", "BLU", "movie-eps", "Eps<br/>", "Episodes", "poster",
        '" style="background-position: center center;background-repeat: no-repeat;background-size:cover;" data-url="',
        "url", '" data-type="', "imdb_rating", ' &nbsp;<i class="fa fa-clock-o"></i> ', "duration",
        'm</div><div class="movie-quality ', '</div><div class="movie-sub">', '</div><div class="movie-title">', "year",
        ")</div></div></div>", '<div style="clear:both;"></div>', ".movie-title", "css", "background", "url('",
        "#home-page-list .movie", "click", "data-type", "#search-mv", "keyup", "val", "#search-mv-btn", "blur",
        "#filter-mv-btn", ".appversion", "Versi ", "play", "movie", "seri", "#player", "data-ref",
        "https://m.akubebas.com/api/mvdata.php", "timeout", "statusText",
        "Pengambilan Data Terlalu Lama, Harap Coba Lagi!", "Terjadi Kesalahan, Harap Coba Lagi!", "plot_tmdb",
        "plot_imdb", "backdrop", "') center center no-repeat", "cover", "data-tmdb", "tmdb", "#player-title", "title",
        "#player-year", "Blu-ray", " (High)", '<i class="fa fa-star"></i> ', ' | <i class="fa fa-clock-o"></i> ',
        " Menit | ", " | ", "country", "#player-genre", "genre", "#player-director", "director", "#player-actor",
        "actor", "#vid-play-icon", "trailerq", "indexOf", "youtube.com", "youtu.be", "http",
        '<iframe id="myvid" width="100%" height="100%" src="https://www.youtube.com/embed/',
        '" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>', "/?token=", "token",
        "&k=", "setHeader", "referer", "https://mob.akubebas.com/movie/", "acceptAllCerts", "data", '[{"sources',
        "[null]", "lastIndexOf", "m.akubebas.com", "adm", "(adm)", "parse", "epis", ".prop-link",
        ".bottom-menu,#vid-play-icon",
        "<a class='prop-link' href='javascript:;' style='color:inherit;'></a>",
        ".bottom-menu", "border-right", "1px solid #555", ".bottom-menu-content a:last-child div", "#bottom-menu-eps",
        "off", "scroll", "scrollTop", ".bottom-menu-content", "fadeIn", "rel", "cam",
        ' style="background:rgba(255,8,8,.8);"', "#player-rel-list", '<div class="movie rel-movie lazy" data-src="',
        '" style="background-position:center center;background-repeat:no-repeat;background-size:cover;" data-url="',
        '"><div class="movie-info"><div class="movie-ratdur"><i class="fa fa-star"></i> ',
        '</div><div class="movie-title" style="white-space:normal;">', "/images/mask-title.png') center top repeat-x",
        "#player-rel-list .rel-movie", "#player-rel-content", "show", "playing", "getState", "getElementById",
        "analytic-frame", "contentWindow", "postMessage", "analytic", "apk-watching", "search", "category", "xcountry",
        "Server Sedang Tidak Stabil, Harap Bersabar dan Coba Lagi Nanti!", "#movies-title", "<b>Category:</b> ",
        "replace", "Movie", "Serial TV", "ucwords", "sub", "sub_id", "sub_en", "Sub Inggris",
        "<b>Hasil Pencarian:</b> ", "xsemi", "insertAfter", "#xsemi-country", "change", "#movies-page-list",
        '<div class="movie lazy" data-src="', '<div id="movies-cfix" style="clear:both;"></div>',
        "#movies-page-list .movie", "Controller", "Scene", "#movies-loader", "onEnter", "addTo", "enter", "hide",
        ".movies-container .movies", '<div style="padding:10px;text-align:center;">Tidak Ada Hasil.</div>',
        ".filter input", "sort", "prop", "checked", "parent", "addClass", ".filter", "input", ":checked", "checkbox",
        "removeClass", "active", "radio", ".filter-input:last-child .filter", ".filter-type:checked", "push",
        ".filter-sort:checked", "stringify", ".eplist", "eps", '<div class="ep ', '" data-child="', '" data-prov="',
        '" data-eps="', '" data-nno="',
        '<div class="eplist"><div style="padding:15px;padding-bottom:5px;font-weight:bold;text-shadow:0 0 3px #9f9f9f;">Pilih Episode</div><div class="divider"></div>',
        ".ep", "unbind", "#myvid, #infosv", "#server-list-title,#server-list-content", "data-child", "data-eps",
        "data-nno", "/?sv=", "&ep=", "&no=", "&v=", "/play", "#player-container", "#featured-refresh-btn",
        "transparent", "onclick", "Mengambil..", "data-url", "#movies-cfix", "destroy", "meta",
        "https://sub.akubebas.com/req/tv/?epNo=", '[{"file"', "backup2", "file", "driveid",
        "?alt=media&key=AIzaSyBXV3qGJ2rwDaxvUmAzaVpZMmn1t6PyU0E", "mp4", "data-lemon", "kuki", "gapake",
        "addEventListener", "deviceready", "insomnia", "keepAwake", "getVersionNumber", "then", "resume",
        "webkitfullscreenchange", "mozfullscreenchange", "fullscreenchange", "MSFullscreenChange", "50vh",
        ".bottom-menu-logo", "100%", "hardsub", "prov", "ratio", "sources", "label", "720p", "360p", ".mp4", "backup",
        "floor", "vid", "html5", "https://indoxxi.vip", "INDOXXI", "true", "uniform", "auto", "seven", "#E3E370",
        "raised", "ready", "buffer", "pause", "seeked", "seek", "captionsList", "error", "levelsChanged",
        "captionsChanged", "complete", '<iframe id="myvid" src="',
        '" frameborder="0" scrolling="no" style="width:100%;height:100%;display:none;" allowfullscreen></iframe>',
        "rapid", "load", "#myvid", "contents", "find", "source", "src", '<div id="vid"></div>', "https:",
        "#mgvideo_html5_api", "HEAD", "onreadystatechange", "readyState", "send", "children",
        "https://oload.stream/stream/", "?mime=true", '" width="100%" height="auto"></div>', ".jwseed", "800px",
        "138px", "80%", "absolute", "50px", "50%", "translateX(-50%)", "getCurrentQuality", "random",
        "#vid > div.jw-media.jw-reset > video", "loadedmetadata", "videoWidth", "videoHeight", "toFixed", "resize",
        "getItem", "getPosition", "setItem", "width", "#bottom-menu-sub", "getCaptionsList", "english",
        "setCurrentCaptions", "getPlaylistItem", "/*/", "Expires", "toString", "Expires=", "/vids/", "data-mp4s",
        "setCurrentQuality", "lemonstream", "mycloud", '<iframe id="myvid" src=\'',
        "' frameborder='0' scrolling='no' style='width:100%;height:100%;' allowfullscreen></iframe>", "splice", "-time",
        "removeItem", "nno", "kds",
        '<div class="jw-logo jw-reset jw-logo-top-right" style="opacity: 1; margin-left: 1.8%; margin-top: 2%; width: 28%; height: 11%; min-height: 6px; min-width: 65px; background-image: url(\'https://img.',
        "div.jw-controls.jw-reset", "/images/indoxx1com.png');\"></div>", "kata2",
        '<div class="jw-logo jw-reset jw-logo-top-right" style="opacity: 1; margin-right: -1.4%; margin-top: 2.2%; width: 18%; height: 9%; min-height: 10px; min-width: 50px; background-image: url(\'',
        '<div class="jw-logo jw-reset jw-logo-top-right" style="opacity: 1; margin-right: 0%; margin-top: 2%; width: 17%; height: 8.5%; min-height: 10px; min-width: 50px; background-image: url(\'',
        '<div class="jw-logo jw-reset jw-logo-top-left" style="opacity: 1; margin-left: 0%; margin-top: -0.4%; width: 18.5%; height: 9%; min-height: 10px; min-width: 50px; background-image: url(\'',
        "nontongo",
        '<div class="jw-logo jw-reset jw-logo-top-left" style="opacity: 1; margin-left: 0%; margin-top: -0.2%; width: 19%; height: 11%; min-height: 6px; min-width: 50px; background-image: url(\'',
        "ns22", '/images/vp-logo-bg.gif\');" data-href="https://indoxxi.vip/tools/"></div>', "ns21",
        '<div class="jw-logo jw-reset jw-logo-top-left" style="opacity: 1; margin-left: 0%; margin-top: -0.3%; width: 17%; height: 11%; min-height: 6px; min-width: 50px; background-image: url(\'',
        '/images/vp-logo-bg.gif\');" data-href="', '/tools/"></div>', "anime",
        '<div class="jw-logo jw-reset jw-logo-top-left" style="opacity: 1; margin-left: 1.5%; margin-top: 1%; width: 28%; height: 12%; min-height: 10px; min-width: 50px; background-image: url(\'',
        "/images/koleksi-anime-notif9.gif');\"></div>",
        '<div class="jw-logo jw-reset jw-logo-top-left" style="opacity: 1; margin-left: 81%; margin-top: 1%; width: 19%; height: 7%; min-height: 10px; min-width: 50px; background-image: url(\'',
        "div.jw-controls.jw-reset > div:nth-child(5)",
        '<div class="jw-logo jw-reset jw-logo-top-left" style="opacity: 1; margin-left: 0.5%; margin-top: 1%; width: 24%; height: 16%; min-height: 28px; min-width: 115px; background-image: url(\'',
        "lkc21",
        '<div class="jw-logo jw-reset jw-logo-top-left" style="opacity: 1; margin-left: 0.5%; margin-top: 0.5%; width: 22%; height: 13%; min-height: 28px; min-width: 115px; background-image: url(\'',
        '<div class="jw-logo jw-reset jw-logo-top-left" style="opacity: 1; margin-left: 0.5%; margin-top: 0.5%; width: 24%; height: 12%; min-height: 28px; min-width: 115px; background-image: url(\'',
        '<div class="jw-logo jw-reset jw-logo-top-left" style="opacity: 1; margin-left: 0.4%; margin-top: 0.4%; width: 24%; height: 12%; min-height: 28px; min-width: 115px; background-image: url(\'',
        ".jw-logo", "data-href", "pop", "<img class='server-icon' src='", "/images/icon-server/4k.png'/>",
        "/images/icon-server/hardsub.png'/>", '<div class="server ', '" data-idx="', " <div>", "</div></div>",
        ".server", "data-idx", "#myvid,#infosv", '/images/icon-server/mp4.png">', "mango",
        '/images/icon-server/mango.png">', '<img class="server-icon" src="', '/images/icon-server/rpid.png">', "oload",
        '/images/icon-server/oload.png">', '/images/icon-server/blogspot.png">', '/images/icon-server/google.png">',
        "#infosv,#player-loader", "#vid-container, #vid",
        '<div id="infosv" style="position:absolute;top:50%;transform: translateY(-50%);color:#f8f8f8;width:100%;height:100%;z-index:9;background:#000;"><div style="display:inline-block;position:relative;top:50%;left:50%;transform:translate(-48%,-50%);padding:10px;"><div style="padding:5px;font-size:1.2em;font-weight:bold;">Mohon Maaf</div><div style="padding:5px;max-width:450px;line-height:1.5;">Untuk Sumber Film Ini Hanya Dapat Diputar Melalui Browser Komputer (Chrome/Firefox) Menggunakan Extension VidPlay.</div></div></div>',
        '/images/err-monster.png" width="140px" height="auto" style="float: left;position: relative;top: -15px;right: 5px;"><div style="padding:5px;font-size:1.2em;font-weight:bold;">Sumber Film Tidak Tersedia!</div><div style="padding:5px;">Silahkan Coba Dalam Beberapa Saat Lagi.</div><div style="clear:both;"></div></div></div>',
        '<div id="infosv" style="position:absolute;top:50%;transform: translateY(-50%);color:#f8f8f8;width:100%;height:100%;z-index:9;background:#000;"><div style="display:inline-block;position:relative;top:50%;left:50%;transform:translate(-48%,-50%);padding:10px;"><img src="',
        "#player-loader", '<div id="player-loader" class="page-overlay" style="background:#000;"><img src="',
        '/images/loading-play.gif" width="auto" height="40%" style="position:relative;top:50%;left:50%;transform:translate(-50%,-50%);-webkit-transform:translate(-50%,-50%);"/></div>',
        "getCurrentCaptions", "plugins", "permissions", "hasPermission", "WRITE_EXTERNAL_STORAGE", "requestPermission",
        "tips", "Pilih Subtitle Terlebih Dahulu Dari Tombol CC Di Player!", "Sumber HARDSUB Tidak Memiliki Subtitle!",
        "file:///storage/emulated/0/Download/", ".srt", "resolveLocalFileSystemURL",
        "Subtitle Yang Sama Sudah Pernah Didownload, Harap Cek Folder Download Anda!",
        "Subtitle Berhasil Didownload, Silahkan Cek <b>Folder Download di Phone Storage</b> Anda!",
        "Film Saat Ini Tidak Dapat Di Download!", "#download-progress-close", "#download-progress",
        ".download-progress", "#download-progress-total", "Download (", "#download-progress-content",
        "#download-progress-title", "Film Yang Sama Sudah Pernah Didownload, Harap Cek Folder Download Anda!",
        "#88ee88", "Tutup", "total", " GB", " MB", "loaded", " KB", "#download-progress-loaded",
        "#download-progress-full", "#download-progress-perc", "download", "scanMedia",
        " Berhasil Didownload, Silahkan Cek <b>Folder Download di Phone Storage</b> Anda!", "Media Refresh Failed: ",
        "Download Gagal, Silahkan Coba Kembali Atau Pilih Sumber Lain!", "#download-progress-list",
        '"></div><div class="download-progress-num"><span id="download-progress-loaded',
        '">0</span> / <span id="download-progress-full',
        '">0</span></div><div class="download-progress-bar"><div class="download-progress-perc" id="download-progress-perc',
        '">&nbsp;</div></div><div class="download-progress-close" id="download-progress-close', '"></div></div>',
        '"><div class="download-progress-title" id="download-progress-title', '"></div></div></div></div>',
        "#download-progress-toggle", ":hidden", "1px solid #afafaf", "3px", "#download-progress-icon", "2em", "-15px",
        "1.5em", "-7px", "cookieEmperor", "https://.google.com", "DRIVE_STREAM", "Success", "Error: ", ".page",
        "Error launching home intent", "last", "#cdv-loader-content",
        '<div id="cdv-loader-content"><div id="cdv-loader"><div class="spinner-label">Loading</div><div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div></div>',
        "innerHeight", "SD.", "HD.", "INDOXXI-[", "_utf8_encode", "charCodeAt", "_keyStr", "charAt", "fromCharCode",
        "_utf8_decode", "decode", "substr", "slice", "seed", ".lazy", "data-src", "background-image", "getMinutes",
        "getSeconds", "getTimezoneOffset", "GMT", "+0700 (SE Asia Standard Time)", "prototype", "toUpperCase",
        "drives_muvi", "drives_lk21", "drives", "blogspot", "mp4s", "blogger", "facebook", "mcloud", "akumenang.com",
        "filter", "failreq", "ajax", "https://m.akubebas.com/api/check.php", "GET", "JSON", "link", "tvReq", "imgReq",
        "/images/indoxxi-yt-c.gif", "/images/banner-729x90-vidplay3.gif", "/images/mn-small.gif",
        "/images/nl-play-1.gif", "/images/poker.gif", "https://xxiyoutube.com", "https://", "/tools",
        "http://nagalaut23.com", "https://pokergolden.biz", "http://masternaga.rocks", "join", "check", "img1",
        "remove", "confirm", '<div><img src="',
        '" height="100px" width="auto"/></div> Versi Aplikasi Anda Telah Usang, Update Ke Versi Terbaru?', "open",
        "_blank", "split", "img2", ".alert_overlay", "alert", "img3",
        '" height="100px" width="auto"/></div> Aplikasi Sedang Maintenance, Harap Coba Lagi Nanti.', "home", "log",
        "Successfully launched home intent", "msg", "length", "img4", '" height="100px" width="auto"/></div> ', "body",
        "prepend",
        '<iframe id="analytic-frame" src="https://m.akubebas.com/analytic.php" style="display:none"></iframe>', "lock",
        "landscape", "video", "attr", "height:auto !important;max-height:99% !important;", "#vid", "style",
        "width:100%;height: ", "height", "px !important;top:50%;-webkit-transform:translateY(-50%);", "#vid-container",
        "px;", "orientation", "unlock", "removeAttr", "fullscreenElement", "webkitFullscreenElement",
        "mozFullScreenElement", "msFullscreenElement", "get", ".html?q=", "getTime", "#cdv-logo", "append",
        '<div class="page" data-page="', '"><div class="page-overlay"></div>', ".category", "each", "movies"];
! function (e, a) {
    ! function (a) {
        for (; --a;) e.push(e.shift())
    }(++a)
}(_0x550c, 486);
var loading, perLoad, controller, scene, lastIndex, dom, mvReq, tvReq, imgReq, currentIdx, ignoreIdx, srcIdx, epArr,
        actEpi, jw, hs, mvid, prov, ar, table, currentKuki, totalQuals, qualIdx, totalTry, maxTry, chgRes,
        playTimeInterval, analIntv, btout, banners, bannersLink, _0x56ae = function (e, a) {
        return _0x550c[e -= 0]
    }, appVersion = "",
    freeze = !1,
    sources = [],
    subtitles = [],
    epi = "-1",
    epiTitle = "",
    noDrive = !1,
    havesend = !1,
    bckupIdx = "",
    mrload = !1,
    uSwitch = !1,
    srvList = !1,
    nextTry = !1,
    extType = [_0x56ae("0x0"), _0x56ae("0x1"), _0x56ae("0x2")],
    noFrameType = [_0x56ae("0x0"), _0x56ae("0x1"), "drives", _0x56ae("0x3"), _0x56ae("0x4"), _0x56ae("0x5"), _0x56ae(
            "0x6")],
    bannedType = ["lemon", _0x56ae("0x7")],
    allowSeek = !0,
    asp = !1,
    subreplace = _0x56ae("0x8"),
    banner = "",
    bannerLink = "",
    bannerShowed = !1,
    tsdiv = 5;

function initLocals() {
    localStorage[_0x56ae("0x9")] || (localStorage[_0x56ae("0x9")] = JSON.stringify({
        type: [],
        sort: "year",
        sub: [],
        genre: [],
        country: [],
        year: []
    })), localStorage[_0x56ae("0xa")] || (localStorage.failreq = 0)
}
function appCheck(e) {
    e && $[_0x56ae("0xb")]({
        url: _0x56ae("0xc"),
        cache: !0,
        timeout: 15e3,
        type: _0x56ae("0xd"),
        dataType: _0x56ae("0xe"),
        error: function () {
            appCheck(e)
        },
        success: function (e) {
            var a = e.version,
                x = e.status,
                t = e[_0x56ae("0xf")];
            switch (dom = e.dom, mvReq = e.mvReq, tvReq = e[_0x56ae("0x10")], imgReq = e[_0x56ae("0x11")], banners = [
                    imgReq + _0x56ae("0x12"), imgReq + _0x56ae("0x13"), imgReq + _0x56ae("0x14"), imgReq + _0x56ae(
                    "0x15"), imgReq + _0x56ae("0x16"), imgReq + "/images/nl-play-1.gif", imgReq +
                    "/images/mn-small.gif", imgReq + "/images/poker.gif", imgReq + _0x56ae("0x14"), imgReq + _0x56ae(
                    "0x15"), imgReq + _0x56ae("0x16")], bannersLink = [_0x56ae("0x17"), _0x56ae("0x18") + dom + _0x56ae(
                    "0x19"), "http://masternaga.rocks", _0x56ae("0x1a"), _0x56ae("0x1b"), _0x56ae("0x1a"), _0x56ae(
                    "0x1c"), _0x56ae("0x1b"), _0x56ae("0x1c"), "http://nagalaut23.com", _0x56ae("0x1b")], 1) {
            // switch (dom = e.dom, mvReq = e.mvReq, tvReq = e[_0x56ae("0x10")], imgReq = e[_0x56ae("0x11")], banners = [
            //         imgReq + _0x56ae("0x12"), imgReq + _0x56ae("0x13"), imgReq + _0x56ae("0x14"), imgReq + _0x56ae(
            //         "0x15"), imgReq + _0x56ae("0x16"), imgReq + "/images/nl-play-1.gif", imgReq +
            //         "/images/mn-small.gif", imgReq + "/images/poker.gif", imgReq + _0x56ae("0x14"), imgReq + _0x56ae(
            //         "0x15"), imgReq + _0x56ae("0x16")], bannersLink = [_0x56ae("0x17"), _0x56ae("0x18") + dom + _0x56ae(
            //         "0x19"), "http://masternaga.rocks", _0x56ae("0x1a"), _0x56ae("0x1b"), _0x56ae("0x1a"), _0x56ae(
            //         "0x1c"), _0x56ae("0x1b"), _0x56ae("0x1c"), "http://nagalaut23.com", _0x56ae("0x1b")], x) {
            case "1":
                if (a > parseInt(appVersion.split(".")[_0x56ae("0x1d")](""))) if (localStorage.check && 0 !=
                        localStorage[_0x56ae("0x1e")]) localStorage[_0x56ae("0x1e")]--;
                    else {
                        var i = e[_0x56ae("0x1f")];
                        $(".alert_overlay")[_0x56ae("0x20")](), $[_0x56ae("0x21")](_0x56ae("0x22") + i + _0x56ae("0x23"), function (
                            e) {
                            e && window[_0x56ae("0x24")](t, _0x56ae("0x25"))
                        }), localStorage[_0x56ae("0x1e")] = 10
                    }
                break;
            case "2":
                a > parseInt(appVersion[_0x56ae("0x26")](".")[_0x56ae("0x1d")]("")) && (i = e[_0x56ae("0x27")], $(
                    _0x56ae("0x28"))[_0x56ae("0x20")](), $[_0x56ae("0x29")](_0x56ae("0x22") + i +
                    '" height="100px" width="auto"/></div> Aplikasi Telah Diperbarui, Install Aplikasi Versi Terbaru Sebelum Melanjutkan!', function () {
                    window[_0x56ae("0x24")](t, "_blank")
                }), localStorage.removeItem(_0x56ae("0x1e")));
                break;
            case "3":
                i = e[_0x56ae("0x2a")], $(_0x56ae("0x28"))[_0x56ae("0x20")](), $[_0x56ae("0x29")](_0x56ae("0x22") + i +
                    _0x56ae("0x2b"), function () {
                    navigator[_0x56ae("0x2c")][_0x56ae("0x2c")](function () {
                        console[_0x56ae("0x2d")](_0x56ae("0x2e"))
                    }, function () {
                        console[_0x56ae("0x2d")]("Error launching home intent")
                    })
                }), localStorage.removeItem(_0x56ae("0x1e"))
            }
            e[_0x56ae("0x2f")] && !$(_0x56ae("0x28"))[_0x56ae("0x30")] && (localStorage.msg && 0 != localStorage[
                _0x56ae("0x2f")] ? localStorage[_0x56ae("0x2f")]-- : (i = e[_0x56ae("0x31")], $.alert(_0x56ae("0x22") +
                i + _0x56ae("0x32") + e[_0x56ae("0x2f")], function () {
                localStorage[_0x56ae("0x2f")] = 10
            }))), $(_0x56ae("0x33"))[_0x56ae("0x34")](_0x56ae("0x35"))
        }
    })
}
function exitHandler(e) {
    isFullScreen() ? (screen.orientation[_0x56ae("0x36")](_0x56ae("0x37")), setTimeout(function () {
        $(_0x56ae("0x38"))[_0x56ae("0x39")]("style", _0x56ae("0x3a")), $(_0x56ae("0x3b"))[_0x56ae("0x39")](_0x56ae(
            "0x3c"), _0x56ae("0x3d") + $(_0x56ae("0x38"))[_0x56ae("0x3e")]() + _0x56ae("0x3f")), $(_0x56ae("0x40")).attr(
            _0x56ae("0x3c"), "height:" + $(_0x56ae("0x38"))[_0x56ae("0x3e")]() + _0x56ae("0x41"))
    }, 500)) : (screen[_0x56ae("0x42")][_0x56ae("0x43")](), setTimeout(function () {
        $("video, #vid, #vid-container")[_0x56ae("0x44")](_0x56ae("0x3c")), $(_0x56ae("0x40"))[_0x56ae("0x3e")]($(
            _0x56ae("0x3b"))[_0x56ae("0x3e")]())
    }, 500))
}
function isFullScreen() {
    return 1 == (document[_0x56ae("0x45")] && null !== document[_0x56ae("0x45")] || document.webkitFullscreenElement &&
        null !== document[_0x56ae("0x46")] || document.mozFullScreenElement && null !== document[_0x56ae("0x47")] ||
        document[_0x56ae("0x48")] && null !== document[_0x56ae("0x48")])
}
function createPage(e, a) {
    loadContainer(1), $[_0x56ae("0x49")](e + _0x56ae("0x4a") + (new Date)[_0x56ae("0x4b")](), function (x) {
        switch ($(_0x56ae("0x4c")).length && $(_0x56ae("0x4c")).remove(), $(_0x56ae("0x33"))[_0x56ae("0x4d")](_0x56ae(
            "0x4e") + e + _0x56ae("0x4f") + x + "</div>"), e) {
        case _0x56ae("0x2c"):
            $(_0x56ae("0x50"))[_0x56ae("0x51")](function () {
                $(this).click(function () {
                    createPage(_0x56ae("0x52"), {
                        category: $(this)[_0x56ae("0x53")]()[_0x56ae("0x54")]()[_0x56ae("0x55")]()
                    })
                })
            }), $.ajax({
                url: _0x56ae("0x56"),
                cache: !1,
                timeout: 15e3,
                type: _0x56ae("0xd"),
                dataType: "JSON",
                data: {
                    key: uniqid()[_0x56ae("0x57")](-8, 10)
                },
                error: function (e) {
                    $(_0x56ae("0x58"))[_0x56ae("0x59")](_0x56ae("0x5a")), $(".page-overlay")[_0x56ae("0x5b")](200),
                        setTimeout(function () {
                        $(_0x56ae("0x5c")).remove(), loadContainer(0)
                    }, 200)
                },
                success: function (e) {
                    var a, x, t;
                    $(_0x56ae("0x58"))[_0x56ae("0x53")]("");
                    for (var i = 0; i < e[_0x56ae("0x30")]; i++) {
                        if (a = "", x = "", t = "", "0" != e[i][_0x56ae("0x5d")] && (a += _0x56ae("0x5e")), "0" != e[i][
                                _0x56ae("0x5f")] && (a += _0x56ae("0x60")), "1" == e[i][_0x56ae("0x61")] || "44" == e[i][
                                _0x56ae("0x61")] || "54" == e[i][_0x56ae("0x61")]) switch (e[i][_0x56ae("0x62")][
                                    _0x56ae("0x55")]()) {
                            case _0x56ae("0x63"):
                                t = _0x56ae("0x64");
                                break;
                            case "cam":
                                t = ' style="background:rgba(255,8,8,.8);"';
                                break;
                            case "sd":
                                t = _0x56ae("0x65");
                                break;
                            case "hd":
                                "3" == e[i][_0x56ae("0x66")] ? (e[i][_0x56ae("0x62")] = "4K", t = _0x56ae("0x67")) : (t =
                                    0 == e[i][_0x56ae("0x68")] ? _0x56ae("0x69") : 1 == e[i][_0x56ae("0x68")] ? _0x56ae(
                                    "0x6a") : _0x56ae("0x6b"), "1" == e[i][_0x56ae("0x66")] && (e[i][_0x56ae("0x62")] =
                                    _0x56ae("0x6c"), 2 == e[i].hd_level && (e[i][_0x56ae("0x62")] = _0x56ae("0x6d"))))
                        } else x = _0x56ae("0x6e"), e[i][_0x56ae("0x62")] = _0x56ae("0x6f") + e[i][_0x56ae("0x70")];
                        $(_0x56ae("0x58"))[_0x56ae("0x4d")]('<div class="movie lazy" data-src="' + e[i][_0x56ae("0x71")] +
                            _0x56ae("0x72") + e[i][_0x56ae("0x73")] + _0x56ae("0x74") + e[i][_0x56ae("0x61")] +
                            '"><div class="movie-info"><div class="movie-ratdur"><i class="fa fa-star"></i> ' + e[i][
                                _0x56ae("0x75")] + _0x56ae("0x76") + e[i][_0x56ae("0x77")] + _0x56ae("0x78") + x + '"' +
                            t + ">" + e[i][_0x56ae("0x62")] + _0x56ae("0x79") + a + _0x56ae("0x7a") + e[i].title + " (" +
                            e[i][_0x56ae("0x7b")] + _0x56ae("0x7c"))
                    }
                    $(_0x56ae("0x58"))[_0x56ae("0x4d")](_0x56ae("0x7d")), $(_0x56ae("0x7e"))[_0x56ae("0x7f")](_0x56ae(
                        "0x80"), _0x56ae("0x81") + imgReq + "/images/mask-title.png') center top repeat-x"), $(_0x56ae(
                        "0x82"))[_0x56ae("0x83")](function () {
                        createPage("play", {
                            url: $(this)[_0x56ae("0x39")]("data-url"),
                            type: $(this)[_0x56ae("0x39")](_0x56ae("0x84"))
                        })
                    }), $(_0x56ae("0x85"))[_0x56ae("0x86")](function (e) {
                        var a = $(this)[_0x56ae("0x87")]()[_0x56ae("0x54")]();
                        13 == e.which && ($(_0x56ae("0x85")).blur(), createPage(_0x56ae("0x52"), {
                            search: a
                        }))
                    }), $(_0x56ae("0x88"))[_0x56ae("0x83")](function () {
                        var e = $(_0x56ae("0x85"))[_0x56ae("0x87")]().trim();
                        $("#search-mv")[_0x56ae("0x89")](), createPage("movies", {
                            search: e
                        })
                    }), $(_0x56ae("0x8a"))[_0x56ae("0x83")](function () {
                        createPage(_0x56ae("0x9"), {
                            dt: localStorage[_0x56ae("0x9")]
                        })
                    }), $(_0x56ae("0x8b")).text(_0x56ae("0x8c") + appVersion), lazy(), $(_0x56ae("0x5c")).fadeOut(200),
                        setTimeout(function () {
                        $(".page-overlay")[_0x56ae("0x20")](), loadContainer(0)
                    }, 200)
                }
            });
            break;
        case _0x56ae("0x8d"):
            var t = _0x56ae("0x8e");
            "2" != a.type && "45" != a[_0x56ae("0x61")] && "55" != a.type || (t = _0x56ae("0x8f")), $(_0x56ae("0x90")).attr(
                "data-type", t), $(_0x56ae("0x90"))[_0x56ae("0x39")](_0x56ae("0x91"), a[_0x56ae("0x73")]), $[_0x56ae(
                "0xb")]({
                url: _0x56ae("0x92"),
                cache: !1,
                timeout: 15e3,
                type: _0x56ae("0xd"),
                dataType: _0x56ae("0xe"),
                data: {
                    slug: a[_0x56ae("0x73")],
                    type: t,
                    key: uniqid()[_0x56ae("0x57")](-8, 10)
                },
                error: function (e) {
                    $(_0x56ae("0x5c"))[_0x56ae("0x5b")](200), setTimeout(function () {
                        $(_0x56ae("0x5c"))[_0x56ae("0x20")](), loadContainer(0), removePage()
                    }, 200), _0x56ae("0x93") == e[_0x56ae("0x94")] ? $.alert(_0x56ae("0x95")) : localStorage[_0x56ae(
                        "0xa")] < 10 ? ($.alert(_0x56ae("0x96")), localStorage.failreq++) : ($[_0x56ae("0x29")](
                        "Server Sedang Tidak Stabil, Harap Bersabar dan Coba Lagi Nanti!"), localStorage[_0x56ae("0xa")] =
                        0)
                },
                success: function (e) {
                    allowSeek = !0, noDrive = !1;
                    var x = e[_0x56ae("0x97")];
                    x || (x = e[_0x56ae("0x98")]), $(_0x56ae("0x3b"))[_0x56ae("0x7f")]({
                        background: _0x56ae("0x81") + e[_0x56ae("0x99")] + _0x56ae("0x9a"),
                        "background-size": _0x56ae("0x9b")
                    }), $(_0x56ae("0x90")).attr(_0x56ae("0x9c"), e[_0x56ae("0x9d")]), $(_0x56ae("0x9e")).text(e[_0x56ae(
                        "0x9f")]), $(_0x56ae("0xa0"))[_0x56ae("0x53")](e[_0x56ae("0x7b")]), "HD" == e[_0x56ae("0x62")] &&
                        ("1" == e[_0x56ae("0x66")] ? (e[_0x56ae("0x62")] = "FULL HD", 2 == e[_0x56ae("0x68")] && (e[
                        _0x56ae("0x62")] = _0x56ae("0xa1"))) : "3" == e[_0x56ae("0x66")] ? e[_0x56ae("0x62")] = "4K HD" :
                        2 == e[_0x56ae("0x68")] && (e[_0x56ae("0x62")] += _0x56ae("0xa2")), 0 == e[_0x56ae("0x68")] &&
                        (e[_0x56ae("0x62")] += " (Low)")), $("#player-data")[_0x56ae("0x59")](_0x56ae("0xa3") + e[
                        _0x56ae("0x75")] + _0x56ae("0xa4") + e[_0x56ae("0x77")] + _0x56ae("0xa5") + e[_0x56ae("0x62")] +
                        _0x56ae("0xa6") + e[_0x56ae("0xa7")]), $(_0x56ae("0xa8"))[_0x56ae("0x53")](e[_0x56ae("0xa9")]),
                        $(_0x56ae("0xaa"))[_0x56ae("0x53")](e[_0x56ae("0xab")]), $(_0x56ae("0xac"))[_0x56ae("0x53")](e[
                        _0x56ae("0xad")]), $("#player-desc")[_0x56ae("0x4d")](x), _0x56ae("0x8e") == t ? $(_0x56ae(
                        "0xae")).click(function () {
                        if (playLoad(), _0x56ae("0x63") == e[_0x56ae("0x62")][_0x56ae("0x55")]()) if (e[_0x56ae("0xaf")]) {
                                var x = "";
                                if (e[_0x56ae("0xaf")][_0x56ae("0xb0")](_0x56ae("0xb1")) > -1 ? x = e[_0x56ae("0xaf")].split(
                                    "v=")[1] : e[_0x56ae("0xaf")][_0x56ae("0xb0")](_0x56ae("0xb2")) > -1 ? x = e[
                                    _0x56ae("0xaf")][_0x56ae("0x26")]("/")[3] : -1 == e[_0x56ae("0xaf")][_0x56ae("0xb0")](
                                    _0x56ae("0xb3")) && (x = e[_0x56ae("0xaf")]), x) {
                                    var t = _0x56ae("0xb4") + x + _0x56ae("0xb5");
                                    $(_0x56ae("0x40"))[_0x56ae("0x59")](t)
                                } else cantPlay()
                            } else cantPlay();
                            else {
                                var i = setTimeout(function () {
                                    $[_0x56ae("0x29")](_0x56ae("0x95"), function () {
                                        i = "", removePage()
                                    })
                                }, 3e4),
                                    _ = getChkSum(e[_0x56ae("0x9d")]),
                                    o = mvReq + _0x56ae("0xb6") + e[_0x56ae("0xb7")] + _0x56ae("0xb8") + _ + "&v=" +
                                        appVersion;
                                actEpi = 0, cordovaHTTP[_0x56ae("0xb9")](_0x56ae("0xba"), _0x56ae("0xbb") + a[_0x56ae(
                                    "0x73")] + "/play"), cordovaHTTP[_0x56ae("0xbc")](!0, function () {
                                    cordovaHTTP[_0x56ae("0x49")](o, {}, {}, function (e) {
                                        if (i) {
                                            clearTimeout(i);
                                            var a = e[_0x56ae("0xbd")]; - 1 == a[_0x56ae("0xb0")](_0x56ae("0xbe")) && -
                                                1 == a[_0x56ae("0xb0")](_0x56ae("0xbf")) && -1 == a[_0x56ae("0xc0")](
                                                "[]") && (a = rc4(_0x56ae("0xc1"), a)), a[_0x56ae("0xb0")](_0x56ae(
                                                "0xc2")) > -1 && (a = a[_0x56ae("0xb0")](_0x56ae("0xbf")) > -1 || a[
                                                _0x56ae("0xc0")]("[]") == a[_0x56ae("0x30")] - 2 ? _0x56ae("0xbf") :
                                                _0x56ae("0xbe") + (a = (a = (a = a.split(_0x56ae("0xc3")))[a[_0x56ae(
                                                "0x30")] - 1][_0x56ae("0x54")]()).split(_0x56ae("0xbe")))[a[_0x56ae(
                                                "0x30")] - 1][_0x56ae("0x54")]()), beginPlay(JSON[_0x56ae("0xc4")](a))
                                        }
                                    })
                                })
                            }
                    }) : $("#vid-play-icon").click(function () {
                        getEpList(e[_0x56ae("0xc5")])
                    }), $(_0x56ae("0xc6")).length || $(_0x56ae("0xc7")).wrap(_0x56ae("0xc8")), $(_0x56ae("0xc9")).css(
                        _0x56ae("0xca"), _0x56ae("0xcb")), $(_0x56ae("0xcc"))[_0x56ae("0x7f")](_0x56ae("0xca"), "0"), $(
                        _0x56ae("0xcd"))[_0x56ae("0x83")](function () {
                        getEpList(e[_0x56ae("0xc5")])
                    }), epArr = e[_0x56ae("0xc5")];
                    var i = 0;
                    if ($(_0x56ae("0x90"))[_0x56ae("0xce")](_0x56ae("0xcf")).on(_0x56ae("0xcf"), function () {
                        var e = $(this)[_0x56ae("0xd0")]();
                        e > i ? $(_0x56ae("0xd1")).fadeOut(100) : $(_0x56ae("0xd1"))[_0x56ae("0xd2")](100), i = e
                    }), e[_0x56ae("0xd3")][_0x56ae("0x30")] > 0) {
                        for (var _, o, r, n = 0; n < e[_0x56ae("0xd3")].length; n++) {
                            if (r = "", _ = "", o = "", "0" != e[_0x56ae("0xd3")][n][_0x56ae("0x5d")] && (r +=
                                '<img src="https://img.akubebas.com/images/US.png"/>'), "0" != e.rel[n][_0x56ae("0x5f")] &&
                                (r += '<img src="https://img.akubebas.com/images/ID.png"/>'), "1" == e.rel[n].type ||
                                "44" == e[_0x56ae("0xd3")][n][_0x56ae("0x61")] || "54" == e[_0x56ae("0xd3")][n][_0x56ae(
                                    "0x61")]) switch (e[_0x56ae("0xd3")][n][_0x56ae("0x62")].toLowerCase()) {
                                case _0x56ae("0x63"):
                                    o = ' style="background:rgba(117,0,214,.8);"';
                                    break;
                                case _0x56ae("0xd4"):
                                    o = _0x56ae("0xd5");
                                    break;
                                case "sd":
                                    o = _0x56ae("0x65");
                                    break;
                                case "hd":
                                    "3" == e[_0x56ae("0xd3")][n].blu ? (e[_0x56ae("0xd3")][n][_0x56ae("0x62")] = "4K",
                                        o = _0x56ae("0x67")) : (o = 0 == e.rel[n][_0x56ae("0x68")] ? _0x56ae("0x69") :
                                        1 == e[_0x56ae("0xd3")][n][_0x56ae("0x68")] ? _0x56ae("0x6a") : _0x56ae("0x6b"),
                                        "1" == e[_0x56ae("0xd3")][n][_0x56ae("0x66")] && (e.rel[n][_0x56ae("0x62")] =
                                        _0x56ae("0x6c"), 2 == e.rel[n][_0x56ae("0x68")] && (e[_0x56ae("0xd3")][n][
                                            _0x56ae("0x62")] = "BLU")))
                            } else _ = _0x56ae("0x6e"), e.rel[n][_0x56ae("0x62")] = _0x56ae("0x6f") + e[_0x56ae("0xd3")][
                                        n][_0x56ae("0x70")];
                            $(_0x56ae("0xd6"))[_0x56ae("0x4d")](_0x56ae("0xd7") + e[_0x56ae("0xd3")][n].poster +
                                _0x56ae("0xd8") + e[_0x56ae("0xd3")][n][_0x56ae("0x73")] + _0x56ae("0x74") + e[_0x56ae(
                                "0xd3")][n][_0x56ae("0x61")] + _0x56ae("0xd9") + e[_0x56ae("0xd3")][n][_0x56ae("0x75")] +
                                _0x56ae("0x76") + e[_0x56ae("0xd3")][n][_0x56ae("0x77")] + _0x56ae("0x78") + _ + '"' +
                                o + ">" + e[_0x56ae("0xd3")][n][_0x56ae("0x62")] + _0x56ae("0x79") + r + _0x56ae("0xda") +
                                e[_0x56ae("0xd3")][n][_0x56ae("0x9f")] + " (" + e.rel[n][_0x56ae("0x7b")] + _0x56ae(
                                "0x7c"))
                        }
                        $(".movie-title")[_0x56ae("0x7f")]("background", _0x56ae("0x81") + imgReq + _0x56ae("0xdb")), $(
                            _0x56ae("0xdc"))[_0x56ae("0x83")](function () {
                            removePage();
                            var e = {
                                url: $(this)[_0x56ae("0x39")]("data-url"),
                                type: $(this)[_0x56ae("0x39")](_0x56ae("0x84"))
                            };
                            setTimeout(function () {
                                createPage("play", e)
                            }, 300)
                        }), $(_0x56ae("0xdd"))[_0x56ae("0xde")](), lazy()
                    }
                    $(_0x56ae("0x5c"))[_0x56ae("0x5b")](200), setTimeout(function () {
                        $(".page-overlay")[_0x56ae("0x20")](), loadContainer(0)
                    }, 200), analIntv && clearInterval(analIntv), analIntv = setInterval(function () {
                        jw && _0x56ae("0xdf") == jw[_0x56ae("0xe0")]() && document[_0x56ae("0xe1")](_0x56ae("0xe2"))[
                            _0x56ae("0xe3")][_0x56ae("0xe4")]({
                            msg: _0x56ae("0xe5"),
                            name: _0x56ae("0xe6"),
                            category: t.ucwords(),
                            label: e[_0x56ae("0x9f")]
                        }, "*")
                    }, 3e5)
                }
            });
            break;
        case "movies":
            var i = a[_0x56ae("0xe7")] ? a[_0x56ae("0xe7")] : "",
                _ = a.category ? a[_0x56ae("0xe8")] : "",
                o = a[_0x56ae("0x9")] ? a[_0x56ae("0x9")] : "";
            a[_0x56ae("0xe9")] && a[_0x56ae("0xe9")], $.ajax({
                url: "https://m.akubebas.com/api/movies.php",
                cache: !1,
                timeout: 15e3,
                type: _0x56ae("0xd"),
                dataType: "JSON",
                data: {
                    search: i,
                    category: _,
                    filter: o,
                    xcountry: a[_0x56ae("0xe9")],
                    limit: 0,
                    key: uniqid()[_0x56ae("0x57")](-5, 10)
                },
                error: function (e) {
                    $(_0x56ae("0x5c"))[_0x56ae("0x5b")](200), setTimeout(function () {
                        $(_0x56ae("0x5c")).remove(), loadContainer(0), removePage()
                    }, 200), "timeout" == e[_0x56ae("0x94")] ? $.alert(_0x56ae("0x95")) : localStorage.failreq < 10 ? (
                        $[_0x56ae("0x29")]("Terjadi Kesalahan, Harap Coba Lagi!"), localStorage.failreq++) : ($[_0x56ae(
                        "0x29")](_0x56ae("0xea")), localStorage.failreq = 0)
                },
                success: function (e) {
                    if (_) $(_0x56ae("0xeb"))[_0x56ae("0x59")](_0x56ae("0xec") + a[_0x56ae("0xe8")].ucwords());
                    else if (o) {
                        var x = "";
                        x += (o = JSON[_0x56ae("0xc4")](o))[_0x56ae("0x61")][_0x56ae("0x1d")](", ")[_0x56ae("0xed")](
                            "1", _0x56ae("0xee")).replace("2", _0x56ae("0xef")), o[_0x56ae("0xa9")].length > 0 && (x +=
                            _0x56ae("0xa6")), x += o[_0x56ae("0xa9")][_0x56ae("0x1d")](", ")[_0x56ae("0xf0")](), o[
                            _0x56ae("0xa7")][_0x56ae("0x30")] > 0 && (x += _0x56ae("0xa6")), x += o[_0x56ae("0xa7")][
                                _0x56ae("0x1d")](", ")[_0x56ae("0xf0")](), o[_0x56ae("0x7b")][_0x56ae("0x30")] > 0 && (
                            x += _0x56ae("0xa6")), x += o[_0x56ae("0x7b")][_0x56ae("0x1d")](", ")[_0x56ae("0xf0")](), o
                            .sub.length > 0 && (x += _0x56ae("0xa6")), x += o[_0x56ae("0xf1")][_0x56ae("0x1d")](",")[
                            _0x56ae("0xed")](_0x56ae("0xf2"), "Sub Indo")[_0x56ae("0xed")](_0x56ae("0xf3"), _0x56ae(
                            "0xf4")), $("#movies-title")[_0x56ae("0x59")]("<b>Hasil Pencarian:</b> " + x)
                    } else $(_0x56ae("0xeb"))[_0x56ae("0x59")](_0x56ae("0xf5") + a[_0x56ae("0xe7")]), _0x56ae("0xf6") ==
                            a.search[_0x56ae("0x55")]() && ($(
                            '<div style="padding-top:15px;"><select id="xsemi-country" style="padding:10px;width:90%;background:#505050;border:0;border-radius:5px;color:#f8f8f8;box-shadow:0 0 3px #f8f8f8;"><option value="">- Pilih Negara -</option><option value="usa">Barat</option><option value="korea">Korea</option><option value="japan">Jepang</option><option value="thailand">Thailand</option><option value="hong kong">Hongkong</option></select></div>')[
                            _0x56ae("0xf7")](_0x56ae("0xeb")), $(_0x56ae("0xf8"))[_0x56ae("0x87")](a[_0x56ae("0xe9")]),
                            setTimeout(function () {
                            $(_0x56ae("0xf8"))[_0x56ae("0xf9")](function () {
                                var e = $(this)[_0x56ae("0x87")]();
                                removePage(), setTimeout(function () {
                                    createPage(_0x56ae("0x52"), {
                                        search: a[_0x56ae("0xe7")],
                                        category: a[_0x56ae("0xe8")],
                                        xcountry: e
                                    })
                                }, 300)
                            })
                        }, 500)); if (e[_0x56ae("0x30")] > 0) {
                        for (var t, i, r, n = 0; n < e.length; n++) {
                            if (t = "", i = "", r = "", "0" != e[n][_0x56ae("0x5d")] && (t +=
                                '<img src="https://img.akubebas.com/images/US.png"/>'), "0" != e[n][_0x56ae("0x5f")] &&
                                (t += _0x56ae("0x60")), "1" == e[n].type || "44" == e[n][_0x56ae("0x61")] || "54" == e[
                                n][_0x56ae("0x61")]) switch (e[n][_0x56ae("0x62")][_0x56ae("0x55")]()) {
                                case "trailer":
                                    r = _0x56ae("0x64");
                                    break;
                                case _0x56ae("0xd4"):
                                    r = _0x56ae("0xd5");
                                    break;
                                case "sd":
                                    r = _0x56ae("0x65");
                                    break;
                                case "hd":
                                    "3" == e[n].blu ? (e[n][_0x56ae("0x62")] = "4K", r = _0x56ae("0x67")) : (r = 0 == e[
                                        n][_0x56ae("0x68")] ? ' style="background:rgba(255, 146, 24, .8);"' : 1 == e[n][
                                            _0x56ae("0x68")] ? _0x56ae("0x6a") : _0x56ae("0x6b"), "1" == e[n].blu && (e[
                                        n][_0x56ae("0x62")] = _0x56ae("0x6c"), 2 == e[n][_0x56ae("0x68")] && (e[n][
                                            _0x56ae("0x62")] = _0x56ae("0x6d"))))
                            } else i = "movie-eps", e[n][_0x56ae("0x62")] = _0x56ae("0x6f") + e[n][_0x56ae("0x70")];
                            $(_0x56ae("0xfa"))[_0x56ae("0x4d")](_0x56ae("0xfb") + e[n].poster +
                                '" style="background-position:center center;background-repeat:no-repeat;background-size:cover;" data-url="' +
                                e[n].url + _0x56ae("0x74") + e[n][_0x56ae("0x61")] +
                                '"><div class="movie-info"><div class="movie-ratdur"><i class="fa fa-star"></i> ' + e[n][
                                    _0x56ae("0x75")] + _0x56ae("0x76") + e[n][_0x56ae("0x77")] +
                                'm</div><div class="movie-quality ' + i + '"' + r + ">" + e[n][_0x56ae("0x62")] +
                                _0x56ae("0x79") + t + _0x56ae("0x7a") + e[n][_0x56ae("0x9f")] + " (" + e[n][_0x56ae(
                                    "0x7b")] + _0x56ae("0x7c"))
                        }
                        $(_0x56ae("0xfa"))[_0x56ae("0x4d")](_0x56ae("0xfc")), $(".movie-title")[_0x56ae("0x7f")](
                            "background", _0x56ae("0x81") + imgReq + _0x56ae("0xdb")), $(_0x56ae("0xfd"))[_0x56ae(
                            "0x83")](function () {
                            createPage(_0x56ae("0x8d"), {
                                url: $(this)[_0x56ae("0x39")]("data-url"),
                                type: $(this)[_0x56ae("0x39")](_0x56ae("0x84"))
                            })
                        }), 24 == $(_0x56ae("0xfd"))[_0x56ae("0x30")] && ($("#movies-loader")[_0x56ae("0xde")](),
                            loading = !1, perLoad = 24, controller || setTimeout(function () {
                            controller = new(ScrollMagic[_0x56ae("0xfe")]), scene = new(ScrollMagic[_0x56ae("0xff")])({
                                triggerElement: _0x56ae("0x100"),
                                triggerHook: _0x56ae("0x101")
                            })[_0x56ae("0x102")](controller).on(_0x56ae("0x103"), function (e) {
                                (lastIndex = $(_0x56ae("0xfd"))[_0x56ae("0x30")]) < perLoad ? $("#movies-loader")[
                                    _0x56ae("0x104")]() : loading || (loading = !0, getMoreMovies(a))
                            })
                        }, 300)), lazy()
                    } else $(_0x56ae("0x105"))[_0x56ae("0x4d")](_0x56ae("0x106"));
                    $(_0x56ae("0x5c"))[_0x56ae("0x5b")](200), setTimeout(function () {
                        $(_0x56ae("0x5c"))[_0x56ae("0x20")](), loadContainer(0)
                    }, 200)
                }
            });
            break;
        case "filter":
            o = JSON[_0x56ae("0xc4")](localStorage[_0x56ae("0x9")]), $(_0x56ae("0x107")).each(function () {
                var e = $(this)[_0x56ae("0x87")]();
                (o[_0x56ae("0x61")][_0x56ae("0xb0")](e) > -1 || o[_0x56ae("0xa9")][_0x56ae("0xb0")](e) > -1 || o[
                    _0x56ae("0xa7")][_0x56ae("0xb0")](e) > -1 || o[_0x56ae("0x7b")][_0x56ae("0xb0")](e) > -1 || o.sub[
                    _0x56ae("0xb0")](e) > -1 || o[_0x56ae("0x108")] == e) && ($(this)[_0x56ae("0x109")](_0x56ae("0x10a"), !
                    0), $(this)[_0x56ae("0x10b")]()[_0x56ae("0x10c")]("active"))
            }), $(_0x56ae("0x10d")).click(function () {
                var e = $(this).find(_0x56ae("0x10e"));
                e.is(_0x56ae("0x10f")) && _0x56ae("0x110") == e[_0x56ae("0x39")]("type") ? ($(this)[_0x56ae("0x111")](
                    _0x56ae("0x112")), e[_0x56ae("0x109")](_0x56ae("0x10a"), !1)) : (_0x56ae("0x113") == e[_0x56ae(
                    "0x39")]("type") && $(_0x56ae("0x114"))[_0x56ae("0x111")](_0x56ae("0x112")), $(this).addClass(
                    _0x56ae("0x112")), e[_0x56ae("0x109")](_0x56ae("0x10a"), !0))
            }), $("#filter-submit")[_0x56ae("0x83")](function () {
                o[_0x56ae("0x61")] = [], $(_0x56ae("0x115")).each(function () {
                    o[_0x56ae("0x61")][_0x56ae("0x116")]($(this)[_0x56ae("0x87")]())
                }), o.genre = [], $(".filter-genre:checked").each(function () {
                    o[_0x56ae("0xa9")][_0x56ae("0x116")]($(this)[_0x56ae("0x87")]())
                }), o[_0x56ae("0xa7")] = [], $(".filter-country:checked")[_0x56ae("0x51")](function () {
                    o.country[_0x56ae("0x116")]($(this)[_0x56ae("0x87")]())
                }), o[_0x56ae("0x7b")] = [], $(".filter-year:checked")[_0x56ae("0x51")](function () {
                    o[_0x56ae("0x7b")][_0x56ae("0x116")]($(this).val())
                }), o[_0x56ae("0xf1")] = [], $(".filter-sub:checked")[_0x56ae("0x51")](function () {
                    o.sub[_0x56ae("0x116")]($(this).val())
                }), o[_0x56ae("0x108")] = $(_0x56ae("0x117"))[_0x56ae("0x87")](), localStorage[_0x56ae("0x9")] = JSON[
                    _0x56ae("0x118")](o), createPage(_0x56ae("0x52"), {
                    filter: localStorage[_0x56ae("0x9")]
                })
            }), $(".page-overlay")[_0x56ae("0x5b")](200), setTimeout(function () {
                $(_0x56ae("0x5c")).remove(), loadContainer(0)
            }, 200)
        }
    })
}
function getEpList(e) {
    var a, x, t, i, _, o = $(_0x56ae("0x90"))[_0x56ae("0x39")](_0x56ae("0x91"));
    $(_0x56ae("0x119"))[_0x56ae("0x20")]();
    for (var r = "", n = 0; n < e[_0x56ae("0x30")]; n++) a = "", x = e[n][_0x56ae("0x9f")][_0x56ae("0xed")](/\\/g, ""),
            t = e[n].prov, i = e[n][_0x56ae("0x11a")], _ = e[n].nno, epi == n && (a = _0x56ae("0x112")), r += _0x56ae(
            "0x11b") + a + _0x56ae("0x11c") + n + _0x56ae("0x11d") + t + _0x56ae("0x11e") + i + _0x56ae("0x11f") + _ +
            '">' + x + "</div>";
    $(_0x56ae("0x90"))[_0x56ae("0x34")](_0x56ae("0x120") + r + "</div>"), $(_0x56ae("0x121"))[_0x56ae("0x122")]()[
        _0x56ae("0x83")](function (e) {
        allowSeek = !0, uSwitch = !1, mrload = !1, srvList = !1, nextTry = !1, havesend = !1, bannerShowed = !1, $(
            _0x56ae("0x123"))[_0x56ae("0x20")](), $(_0x56ae("0x124")).fadeOut(), epi = $(this)[_0x56ae("0x39")](_0x56ae(
            "0x125")), epiTitle = $(this)[_0x56ae("0x53")]();
        var a = $(this)[_0x56ae("0x39")]("data-prov"),
            x = $(this).attr(_0x56ae("0x126")),
            t = $(this)[_0x56ae("0x39")](_0x56ae("0x127"));
        playLoad();
        var i = getChkSum($(_0x56ae("0x90"))[_0x56ae("0x39")]("data-tmdb")),
            _ = tvReq + _0x56ae("0x128") + a + _0x56ae("0x129") + x + _0x56ae("0x12a") + t + _0x56ae("0xb8") + i +
                _0x56ae("0x12b") + appVersion;
        actEpi = x, cordovaHTTP[_0x56ae("0xb9")](_0x56ae("0xba"), "https://mob.akubebas.com/film-seri/" + o + _0x56ae(
            "0x12c")), cordovaHTTP[_0x56ae("0xbc")](!0, function () {
            cordovaHTTP[_0x56ae("0x49")](_, {}, {}, function (e) {
                var a = e[_0x56ae("0xbd")]; - 1 == a[_0x56ae("0xb0")](_0x56ae("0xbe")) && -1 == a.indexOf(_0x56ae(
                    "0xbf")) && -1 == a[_0x56ae("0xc0")]("[]") && (a = rc4(_0x56ae("0xc1"), a)), a[_0x56ae("0xb0")](
                    _0x56ae("0xc2")) > -1 && (a = a[_0x56ae("0xb0")](_0x56ae("0xbf")) > -1 || a[_0x56ae("0xc0")]("[]") ==
                    a.length - 2 ? _0x56ae("0xbf") : _0x56ae("0xbe") + (a = (a = (a = a[_0x56ae("0x26")](_0x56ae("0xc3")))[
                    a.length - 1].trim())[_0x56ae("0x26")](_0x56ae("0xbe")))[a[_0x56ae("0x30")] - 1].trim()), beginPlay(
                    JSON[_0x56ae("0xc4")](a))
            })
        })
    }), setTimeout(function () {
        $(_0x56ae("0x12d")).on("click", function () {
            $(_0x56ae("0x12d")).off(_0x56ae("0x83")), $(".eplist").remove()
        })
    }, 500)
}
function getRecommends() {
    $(_0x56ae("0x12e"))[_0x56ae("0x7f")]({
        background: _0x56ae("0x12f"),
        border: "0"
    })[_0x56ae("0x44")](_0x56ae("0x130"))[_0x56ae("0x53")](_0x56ae("0x131")), $[_0x56ae("0xb")]({
        url: _0x56ae("0x56"),
        cache: !1,
        timeout: 15e3,
        type: _0x56ae("0xd"),
        dataType: _0x56ae("0xe"),
        data: {
            key: uniqid()[_0x56ae("0x57")](-8, 10)
        },
        error: function () {
            $(_0x56ae("0x58"))[_0x56ae("0x59")](_0x56ae("0x5a")), localStorage.failreq < 10 ? localStorage[_0x56ae(
                "0xa")]++ : ($[_0x56ae("0x29")]("Server Sedang Tidak Stabil, Harap Bersabar dan Coba Lagi Nanti!"),
                localStorage[_0x56ae("0xa")] = 0)
        },
        success: function (e) {
            var a, x, t;
            $(_0x56ae("0x58")).text("");
            for (var i = 0; i < e.length; i++) {
                if (a = "", x = "", t = "", "0" != e[i].suben_count && (a += _0x56ae("0x5e")), "0" != e[i].subid_count &&
                    (a += _0x56ae("0x60")), "1" == e[i].type || "44" == e[i].type || "54" == e[i][_0x56ae("0x61")])
                    switch (e[i][_0x56ae("0x62")][_0x56ae("0x55")]()) {
                    case _0x56ae("0x63"):
                        t = _0x56ae("0x64");
                        break;
                    case _0x56ae("0xd4"):
                        t = _0x56ae("0xd5");
                        break;
                    case "sd":
                        t = _0x56ae("0x65");
                        break;
                    case "hd":
                        "3" == e[i][_0x56ae("0x66")] ? (e[i].quality = "4K", t =
                            ' style="background: linear-gradient(#b07b01, #ffec83, #b07b01)!important;color: #191919 !important;font-weight: 800 !important;"') :
                            (t = 0 == e[i][_0x56ae("0x68")] ? _0x56ae("0x69") : 1 == e[i][_0x56ae("0x68")] ? _0x56ae(
                            "0x6a") : _0x56ae("0x6b"), "1" == e[i][_0x56ae("0x66")] && (e[i][_0x56ae("0x62")] = _0x56ae(
                            "0x6c"), 2 == e[i][_0x56ae("0x68")] && (e[i][_0x56ae("0x62")] = "BLU")))
                } else x = "movie-eps", e[i].quality = _0x56ae("0x6f") + e[i][_0x56ae("0x70")];
                $(_0x56ae("0x58"))[_0x56ae("0x4d")](_0x56ae("0xfb") + e[i][_0x56ae("0x71")] + _0x56ae("0xd8") + e[i][
                        _0x56ae("0x73")] + '" data-type="' + e[i].type + _0x56ae("0xd9") + e[i][_0x56ae("0x75")] +
                    ' &nbsp;<i class="fa fa-clock-o"></i> ' + e[i][_0x56ae("0x77")] + _0x56ae("0x78") + x + '"' + t +
                    ">" + e[i][_0x56ae("0x62")] + _0x56ae("0x79") + a + _0x56ae("0x7a") + e[i][_0x56ae("0x9f")] + " (" +
                    e[i][_0x56ae("0x7b")] + _0x56ae("0x7c"))
            }
            $(_0x56ae("0x58"))[_0x56ae("0x4d")](_0x56ae("0x7d")), $(_0x56ae("0x7e")).css(_0x56ae("0x80"), _0x56ae(
                "0x81") + imgReq + _0x56ae("0xdb")), $(_0x56ae("0x82"))[_0x56ae("0x83")](function () {
                createPage(_0x56ae("0x8d"), {
                    url: $(this)[_0x56ae("0x39")](_0x56ae("0x132")),
                    type: $(this)[_0x56ae("0x39")](_0x56ae("0x84"))
                })
            }), lazy()
        }
    })
}
function getMoreMovies(e) {
    $[_0x56ae("0xb")]({
        url: "https://m.akubebas.com/api/movies.php",
        cache: !1,
        timeout: 15e3,
        type: "GET",
        dataType: _0x56ae("0xe"),
        data: {
            search: e[_0x56ae("0xe7")],
            category: e[_0x56ae("0xe8")],
            filter: e[_0x56ae("0x9")],
            xcountry: e[_0x56ae("0xe9")],
            limit: lastIndex,
            key: uniqid()[_0x56ae("0x57")](-5, 10)
        },
        error: function () {
            getMoreMovies(e)
        },
        success: function (e) {
            if (e.length > 0) {
                var a, x, t;
                $(_0x56ae("0x133"))[_0x56ae("0x20")]();
                for (var i = 0; i < e[_0x56ae("0x30")]; i++) {
                    if (a = "", x = "", t = "", "0" != e[i][_0x56ae("0x5d")] && (a += _0x56ae("0x5e")), "0" != e[i][
                            _0x56ae("0x5f")] && (a += _0x56ae("0x60")), "1" == e[i][_0x56ae("0x61")] || "44" == e[i][
                            _0x56ae("0x61")] || "54" == e[i][_0x56ae("0x61")]) switch (e[i][_0x56ae("0x62")][_0x56ae(
                                "0x55")]()) {
                        case _0x56ae("0x63"):
                            t = _0x56ae("0x64");
                            break;
                        case "cam":
                            t = ' style="background:rgba(255,8,8,.8);"';
                            break;
                        case "sd":
                            t = _0x56ae("0x65");
                            break;
                        case "hd":
                            "3" == e[i][_0x56ae("0x66")] ? (e[i].quality = "4K", t =
                                ' style="background: linear-gradient(#b07b01, #ffec83, #b07b01)!important;color: #191919 !important;font-weight: 800 !important;"') :
                                (t = 0 == e[i][_0x56ae("0x68")] ? _0x56ae("0x69") : 1 == e[i][_0x56ae("0x68")] ?
                                ' style="background:rgba(11,171,0,.8);"' : _0x56ae("0x6b"), "1" == e[i].blu && (e[i][
                                    _0x56ae("0x62")] = _0x56ae("0x6c"), 2 == e[i][_0x56ae("0x68")] && (e[i].quality =
                                _0x56ae("0x6d"))))
                    } else x = _0x56ae("0x6e"), e[i][_0x56ae("0x62")] = "Eps<br/>" + e[i][_0x56ae("0x70")];
                    $(_0x56ae("0xfa")).append(_0x56ae("0xfb") + e[i][_0x56ae("0x71")] + _0x56ae("0xd8") + e[i][_0x56ae(
                            "0x73")] + _0x56ae("0x74") + e[i][_0x56ae("0x61")] + _0x56ae("0xd9") + e[i][_0x56ae("0x75")] +
                        _0x56ae("0x76") + e[i][_0x56ae("0x77")] + _0x56ae("0x78") + x + '"' + t + ">" + e[i][_0x56ae(
                            "0x62")] + _0x56ae("0x79") + a + _0x56ae("0x7a") + e[i][_0x56ae("0x9f")] + " (" + e[i][
                            _0x56ae("0x7b")] + _0x56ae("0x7c"))
                }
                $(_0x56ae("0xfa"))[_0x56ae("0x4d")]('<div id="movies-cfix" style="clear:both;"></div>'), $(_0x56ae(
                    "0x7e"))[_0x56ae("0x7f")](_0x56ae("0x80"), _0x56ae("0x81") + imgReq +
                    "/images/mask-title.png') center top repeat-x"), $(_0x56ae("0xfd")).unbind()[_0x56ae("0x83")](function () {
                    createPage("play", {
                        url: $(this)[_0x56ae("0x39")](_0x56ae("0x132")),
                        type: $(this)[_0x56ae("0x39")](_0x56ae("0x84"))
                    })
                }), lazy()
            } else $(_0x56ae("0x100"))[_0x56ae("0x104")](), controller[_0x56ae("0x134")](!0), controller = null, scene =
                    null;
            loading = !1
        }
    })
}
function beginPlay(e) {
    var a, x = !1,
        t = e[_0x56ae("0x30")];
    t > 0 && !e[0] ? cantPlay() : setTimeout(function () {
        if (srcIdx = [], sources = [], t > 1 && e[t - 1] && !e[t - 1][_0x56ae("0x135")]) subtitles = e[t - 1], t--;
        else if (!havesend) {
            havesend = !0;
            var i = "movie" == $(_0x56ae("0x90"))[_0x56ae("0x39")](_0x56ae("0x84")) ?
                "https://sub.akubebas.com/req/mv/?epNo=0" : _0x56ae("0x136") + actEpi;
            cordovaHTTP[_0x56ae("0xbc")](!0, function () {
                cordovaHTTP.get(i, {}, {}, function (e) {
                    var a = e[_0x56ae("0xbd")];
                    a && a[_0x56ae("0xb0")]('[{"file"') > -1 && (a = '[{"file"' + (a = a[_0x56ae("0x26")](_0x56ae(
                        "0x137")))[a[_0x56ae("0x30")] - 1])[_0x56ae("0x30")] > 5 && -1 == a[_0x56ae("0xb0")](_0x56ae(
                        "0xc3")) && a[_0x56ae("0xb0")](_0x56ae("0x137")) > -1 && (subtitles = JSON[_0x56ae("0xc4")](a))
                })
            })
        }
        e[t - 1] || t--, setTimeout(function () {
            for (var i = 0; i < t; i++) {
                if (e[i][_0x56ae("0x135")][_0x56ae("0x138")]) for (var _ = 0; _ < e[i][_0x56ae("0x135")][_0x56ae(
                            "0x138")][_0x56ae("0x30")]; _++) e[i][_0x56ae("0x135")][_0x56ae("0x138")][_][_0x56ae(
                                "0x139")] = {
                            file: "https://www.googleapis.com/drive/v3/files/" + e[i][_0x56ae("0x135")][_0x56ae("0x138")][
                                    _][_0x56ae("0x13a")] + _0x56ae("0x13b"),
                            type: _0x56ae("0x13c")
                };
                sources[_0x56ae("0x116")](e[i]), "lemon" == e[i][_0x56ae("0x135")][_0x56ae("0x61")] && $(_0x56ae("0x90"))[
                    _0x56ae("0x39")](_0x56ae("0x13d"), "1"), x || (e[i][_0x56ae("0x135")][_0x56ae("0x61")][_0x56ae(
                        "0xb0")](_0x56ae("0x2")) > -1 || noDrive) && -1 == bannedType.indexOf(e[i].meta[_0x56ae("0x61")]) &&
                    (srcIdx[_0x56ae("0x116")](i), currentIdx = i, e[i].meta[_0x56ae("0x13e")] && _0x56ae("0x13f") != e[
                    i].meta[_0x56ae("0x13e")] ? (a || (a = e[i]), setCookie(e[i].meta[_0x56ae("0x13e")]), setTimeout(function () {
                    startPlay(a), a = ""
                }, 300)) : startPlay(e[i]), x = !0)
            }
            x || (noDrive ? cantPlay() : (noDrive = !0, beginPlay(e)))
        }, 300)
    }, 300)
}
document[_0x56ae("0x140")]("backbutton", function () {
    freeze || removePage()
}, !1), document[_0x56ae("0x140")](_0x56ae("0x141"), function () {
    window.plugins[_0x56ae("0x142")][_0x56ae("0x143")](), cordova.getAppVersion[_0x56ae("0x144")]()[_0x56ae("0x145")](function (
        e) {
        appVersion = e, $(_0x56ae("0x8b"))[_0x56ae("0x53")](_0x56ae("0x8c") + appVersion), appCheck(appVersion)
    }), initLocals(), createPage("home"), document[_0x56ae("0x140")](_0x56ae("0x146"), function () {
        appCheck(appVersion), 1 == $(".page")[_0x56ae("0x30")] && getRecommends()
    }, !1)
}, !1), document[_0x56ae("0x140")](_0x56ae("0x147"), exitHandler, !1), document[_0x56ae("0x140")](_0x56ae("0x148"),
    exitHandler, !1), document[_0x56ae("0x140")](_0x56ae("0x149"), exitHandler, !1), document.addEventListener(_0x56ae(
    "0x14a"), exitHandler, !1);
var defRatio = 0;

function startPlay(e) {
    if ("iframe" == e.meta[_0x56ae("0x61")]) {
        var a = '<iframe id="myvid" width="100%" height="100%" src="https://www.youtube.com/embed/' + e.sources[0][
                _0x56ae("0x139")][_0x56ae("0x26")]("v=")[1] + _0x56ae("0xb5");
        return $(_0x56ae("0x40"))[_0x56ae("0x3e")](_0x56ae("0x14b"))[_0x56ae("0x59")](a), $(_0x56ae("0x14c"))[_0x56ae(
            "0x104")](), void $(_0x56ae("0xcd"))[_0x56ae("0x7f")]("width", _0x56ae("0x14d"))[_0x56ae("0xde")]()
    }
    hs = e[_0x56ae("0x135")][_0x56ae("0x14e")], mvid = e[_0x56ae("0x135")].id, prov = e[_0x56ae("0x135")][_0x56ae(
            "0x14f")], 0 == defRatio && 0 != e[_0x56ae("0x135")][_0x56ae("0x150")] && (defRatio = e.meta[_0x56ae(
        "0x150")]), 0 == defRatio && (defRatio = 1.78), ar = "0" == e[_0x56ae("0x135")].ratio ? defRatio : e[_0x56ae(
        "0x135")][_0x56ae("0x150")], table = e.meta[_0x56ae("0x61")], currentKuki = e.meta[_0x56ae("0x13e")] && _0x56ae(
        "0x13f") != e.meta[_0x56ae("0x13e")] ? e[_0x56ae("0x135")][_0x56ae("0x13e")] : "";
    var x, t = ar + ":1";
    subtitles[_0x56ae("0x30")] > 0 && "0" == hs && (x = subtitles);
    for (var i = 0; i < e[_0x56ae("0x151")][_0x56ae("0x30")]; i++) e.sources[i][_0x56ae("0x152")] && ("hd" == e[_0x56ae(
            "0x151")][i][_0x56ae("0x152")][_0x56ae("0x55")]() ? e[_0x56ae("0x151")][i].label = _0x56ae("0x153") : "sd" ==
            e[_0x56ae("0x151")][i].label[_0x56ae("0x55")]() && (e.sources[i][_0x56ae("0x152")] = _0x56ae("0x154")));
    if (-1 != noFrameType.indexOf(table) || mrload || -1 != e[_0x56ae("0x151")][0][_0x56ae("0x139")][_0x56ae("0x55")]()[
        _0x56ae("0xb0")](_0x56ae("0x155"))) {
        var _ = e[_0x56ae("0x151")];
        e[_0x56ae("0x135")][_0x56ae("0x13e")] && "gapake" != e[_0x56ae("0x135")][_0x56ae("0x13e")] || (e[_0x56ae(
            "0x135")][_0x56ae("0x156")] ? _ = e.meta[_0x56ae("0x156")] : e[_0x56ae("0x135")][_0x56ae("0x138")] && e.meta[
            _0x56ae("0x138")][_0x56ae("0x30")] > 0 && (bckupIdx = Math[_0x56ae("0x157")](Math.random() * e[_0x56ae(
            "0x135")][_0x56ae("0x138")][_0x56ae("0x30")]), _ = e[_0x56ae("0x135")][_0x56ae("0x138")][bckupIdx][_0x56ae(
                "0x139")])), jw && (jwplayer(_0x56ae("0x158"))[_0x56ae("0x20")](), jw = null), (jw = jwplayer(_0x56ae(
            "0x158")).setup({
            primary: _0x56ae("0x159"),
            width: _0x56ae("0x14d"),
            height: _0x56ae("0x14d"),
            aboutlink: _0x56ae("0x15a"),
            abouttext: _0x56ae("0x15b"),
            aspectratio: t,
            autostart: _0x56ae("0x15c"),
            stretching: _0x56ae("0x15d"),
            preload: _0x56ae("0x15e"),
            controls: !0,
            sharing: {},
            skin: {
                name: _0x56ae("0x15f")
            },
            captions: {
                color: _0x56ae("0x160"),
                backgroundOpacity: 60,
                fontSize: 10,
                edgeStyle: _0x56ae("0x161")
            },
            sources: _,
            tracks: x
        })).on(_0x56ae("0x162"), onReady), jw.on(_0x56ae("0x163"), onBuffer), jw.on(_0x56ae("0x8d"), onPlay), jw.on(
            _0x56ae("0x164"), onPause), jw.on(_0x56ae("0x165"), onSeeked), jw.on(_0x56ae("0x166"), onSeek), jw.on(
            _0x56ae("0x167"), onCaptionList), jw.on(_0x56ae("0x168"), onError), jw.on(_0x56ae("0x169"), onLevelsChanged),
            jw.on(_0x56ae("0x16a"), onCaptionsChanged), jw.on(_0x56ae("0x16b"), onComplete)
    } else a = _0x56ae("0x16c") + e.sources[0][_0x56ae("0x139")] + _0x56ae("0x16d"), $(_0x56ae("0x40")).html(a),
            playLoad(), _0x56ae("0x16e") == table && $("#myvid").on(_0x56ae("0x16f"), function () {
            mrload = !0;
            var e = $(_0x56ae("0x170"))[_0x56ae("0x171")]()[_0x56ae("0x172")](_0x56ae("0x173"))[_0x56ae("0x39")](
                _0x56ae("0x174"));
            sources[currentIdx].sources[0][_0x56ae("0x139")] = e, $(_0x56ae("0x170")).remove(), $(_0x56ae("0x40"))[
                _0x56ae("0x59")](_0x56ae("0x175")), startPlay(sources[currentIdx])
        }), "mango" == table && $(_0x56ae("0x170")).on(_0x56ae("0x16f"), function () {
            mrload = !0;
            var e = _0x56ae("0x176") + $(_0x56ae("0x170"))[_0x56ae("0x171")]()[_0x56ae("0x172")](_0x56ae("0x177"))[
                _0x56ae("0x39")](_0x56ae("0x174"));
            if (-1 == e.indexOf(_0x56ae("0x155"))) {
                var a = new XMLHttpRequest;
                a.open(_0x56ae("0x178"), e), a[_0x56ae("0x179")] = function () {
                    this[_0x56ae("0x17a")] == this.DONE && (e = this.responseURL, sources[currentIdx][_0x56ae("0x151")][
                            0][_0x56ae("0x139")] = e, sources[currentIdx][_0x56ae("0x151")][0][_0x56ae("0x61")] =
                        _0x56ae("0x13c"), $(_0x56ae("0x170"))[_0x56ae("0x20")](), $(_0x56ae("0x40")).html(
                        '<div id="vid"></div>'), startPlay(sources[currentIdx]))
                }, a[_0x56ae("0x17b")]()
            } else sources[currentIdx].sources[0][_0x56ae("0x139")] = e, sources[currentIdx][_0x56ae("0x151")][0][
                        _0x56ae("0x61")] = _0x56ae("0x13c"), $("#myvid")[_0x56ae("0x20")](), $(_0x56ae("0x40")).html(
                    _0x56ae("0x175")), startPlay(sources[currentIdx])
        }), "oload" == table && $(_0x56ae("0x170")).on(_0x56ae("0x16f"), function () {
            mrload = !0;
            var e = $(_0x56ae("0x170"))[_0x56ae("0x171")]()[_0x56ae("0x172")]("div[style='display:none;']")[_0x56ae(
                "0x17c")]().last()[_0x56ae("0x53")]()[_0x56ae("0x54")]();
            e = _0x56ae("0x17d") + e + _0x56ae("0x17e"), sources[currentIdx][_0x56ae("0x151")][0][_0x56ae("0x139")] = e,
                $(_0x56ae("0x170")).remove(), $(_0x56ae("0x40"))[_0x56ae("0x59")](_0x56ae("0x175")), startPlay(sources[
                currentIdx])
        })
}
function showBanner(e, a) {
    $(".jwseed")[_0x56ae("0x20")](), $(_0x56ae("0x40"))[_0x56ae("0x34")](
        '<div class="jwseed" onclick="event.stopPropagation();" style="position:relative;z-index:2;"><div id="banner-close" onclick="event.stopPropagation();$(this).parent().hide();" style="background:#111;color:#f8f8f8;font-weight:bold;font-size:0.9em;width:20px;line-height:20px;text-align:center;position:absolute;top:3px;right:3px;z-index:2;">X</div><img src="' +
        e + _0x56ae("0x17f")), $(_0x56ae("0x180"))[_0x56ae("0x7f")]({
        width: _0x56ae("0x181"),
        height: _0x56ae("0x182"),
        "max-width": _0x56ae("0x183"),
        "max-height": "20%",
        position: _0x56ae("0x184"),
        bottom: _0x56ae("0x185"),
        left: _0x56ae("0x186"),
        transform: _0x56ae("0x187")
    }), $(_0x56ae("0x180"))[_0x56ae("0x122")]()[_0x56ae("0x83")](function () {
        window[_0x56ae("0x24")](a, "_blank")
    })
}
function onReady() {
    totalQuals = jw.getPlaylistItem()[_0x56ae("0x151")][_0x56ae("0x30")] - 1, qualIdx = jw[_0x56ae("0x188")](),
        totalTry = 0, nextTry = !1, chgRes = !1, maxTry = null;
    var e = Math[_0x56ae("0x157")](Math[_0x56ae("0x189")]() * banners[_0x56ae("0x30")] + 0);
    1 == e && (e = 0), banner = banners[e], bannerLink = bannersLink[e], bannerShowed = !1, $(_0x56ae("0x18a")).on(
        _0x56ae("0x18b"), function () {
        var e = this[_0x56ae("0x18c")] / this[_0x56ae("0x18d")];
        e = e[_0x56ae("0x18e")](2), ar != e && (ar = e, sources[currentIdx][_0x56ae("0x135")][_0x56ae("0x150")] = ar,
            startPlay(sources[currentIdx]))
    })
}
function onBuffer() {
    appendLogo(ar, prov), $("#player-loader,.jw-settings-sharing")[_0x56ae("0x20")](), $("#vid-container")[_0x56ae(
        "0x3e")]($("#vid").height()), $(window)[_0x56ae("0xce")](_0x56ae("0x18f")).on(_0x56ae("0x18f"), function () {
        $(_0x56ae("0x40"))[_0x56ae("0x3e")]($(_0x56ae("0x3b"))[_0x56ae("0x3e")]())
    })
}
function onPlay() {
    srvList || (srvList = !0, serverList(), $(_0x56ae("0x124"))[_0x56ae("0xd2")]());
    var e = 3,
        a = $(_0x56ae("0x90"))[_0x56ae("0x39")]("data-type");
    "movie" == a && (e = 2), subtitles && 0 != subtitles[_0x56ae("0x30")] || e--;
    var x = "-1" == epi ? "" : epi,
        t = $(_0x56ae("0x90"))[_0x56ae("0x39")]("data-tmdb") + "-" + x + "-time";
    localStorage[_0x56ae("0x190")](t) && allowSeek && (allowSeek = !1, jw[_0x56ae("0x166")](localStorage[_0x56ae(
        "0x190")](t))), playTimeInterval && clearInterval(playTimeInterval), playTimeInterval = setInterval(function () {
        jw && jw[_0x56ae("0x191")]() > 60 ? localStorage[_0x56ae("0x192")](t, jw[_0x56ae("0x191")]()) : clearInterval(
            playTimeInterval)
    }, 3e3), $(_0x56ae("0x14c")).hide(), $(_0x56ae("0xc9")).css(_0x56ae("0x193"), 100 / e + "%")[_0x56ae("0xde")](),
        "movie" == a && $(_0x56ae("0xcd"))[_0x56ae("0x104")](), subtitles && 0 != subtitles[_0x56ae("0x30")] || $(
        _0x56ae("0x194"))[_0x56ae("0x104")](), btout && clearTimeout(btout), jw[_0x56ae("0x191")]() < 10 ? ($(".jwseed")[
        _0x56ae("0xde")](), btout = setTimeout(function () {
        $(_0x56ae("0x180"))[_0x56ae("0x104")]()
    }, 1e3 * (10 - jw.getPosition()))) : $(_0x56ae("0x180"))[_0x56ae("0x104")]()
}
function onPause() {
    btout && clearTimeout(btout), $(_0x56ae("0x180")).show()
}
function onSeek() {}
function onSeeked() {
    jw[_0x56ae("0x191")]() > 10 && $(_0x56ae("0x180"))[_0x56ae("0x104")]()
}
function onCaptionList() {
    var e = jw[_0x56ae("0x195")]();
    if (e[_0x56ae("0x30")] > 0) {
        for (var a = _0x56ae("0xce"), x = 0; x < e[_0x56ae("0x30")]; x++) if ("off" != (a = e[x][_0x56ae("0x152")][
                    _0x56ae("0x55")]())) {
                if (-1 == a[_0x56ae("0xb0")](_0x56ae("0x196"))) {
                    a = x;
                    break
                }
                a = x
            }
        _0x56ae("0xce") != a && jw[_0x56ae("0x197")](a)
    }
}
function onError() {
    allowSeek = !0;
    var e = JSON[_0x56ae("0x118")](jw[_0x56ae("0x198")]()[_0x56ae("0x151")]);
    if (e.indexOf(_0x56ae("0x199")) > -1 || _0x56ae("0x4") == table) if (maxTry ? maxTry-- : e[_0x56ae("0xb0")](_0x56ae(
            "0x199")) > -1 && "mp4s" != table ? maxTry = 2 : (maxTry = 2, "lk" == prov && e[_0x56ae("0xb0")](_0x56ae(
            "0x19a")) > -1 && parseInt((new Date)[_0x56ae("0x4b")]()[_0x56ae("0x19b")]().substring(0, 10)) <= parseInt(
            sources[currentIdx][_0x56ae("0x151")][0][_0x56ae("0x139")][_0x56ae("0x26")](_0x56ae("0x19c"))[1][_0x56ae(
                "0x26")]("&")[0]) && (maxTry = 6)), maxTry) e = e[_0x56ae("0xb0")](_0x56ae("0x199")) > -1 && sources[
                currentIdx][_0x56ae("0x135")][_0x56ae("0x156")] && "mp4s" != table ? sources[currentIdx][_0x56ae(
                    "0x135")][_0x56ae("0x156")] : jw.getPlaylistItem()[_0x56ae("0x151")], jw.load(jw[_0x56ae("0x198")]());
        else {
            if (nextTry = !0, e[_0x56ae("0xb0")]("/*/") > -1 && _0x56ae("0x4") != table && (sources[currentIdx][_0x56ae(
                    "0x135")].backup && (sources[currentIdx][_0x56ae("0x135")][_0x56ae("0x156")] = ""), sources[
                currentIdx][_0x56ae("0x135")][_0x56ae("0x138")] && sources[currentIdx][_0x56ae("0x135")][_0x56ae(
                    "0x138")][_0x56ae("0x30")] > 0)) return void startPlay(sources[currentIdx]);
            if (uSwitch) if ("mp4s" == table && ignoreIdx[_0x56ae("0x116")](currentIdx), e[_0x56ae("0xb0")](_0x56ae(
                    "0x19d")) > -1) $(_0x56ae("0x90"))[_0x56ae("0x39")](_0x56ae("0x19e"), "1"), cantPlay();
                else {
                    if (sources[currentIdx][_0x56ae("0x135")][_0x56ae("0x138")] && sources[currentIdx].meta[_0x56ae(
                        "0x138")][_0x56ae("0x30")] > 0) return void startPlay(sources[currentIdx]);
                    _0x56ae("0x4") != table && ignoreIdx.push(currentIdx), errPlay()
                }
        } else if ("blogspot" == table || _0x56ae("0x5") == table) maxTry || (maxTry = 3 * (totalQuals + 1)), totalTry <
            maxTry ? (!1 === chgRes ? ++qualIdx > totalQuals && (qualIdx = 0) : qualIdx = chgRes, setTimeout(function () {
            jw.load(jw[_0x56ae("0x198")]()), jw[_0x56ae("0x19f")](qualIdx), jw[_0x56ae("0x166")](1), totalTry++
        }, 0)) : (nextTry = !0, uSwitch && (ignoreIdx[_0x56ae("0x116")](currentIdx), errPlay()));
    else if (-1 == noFrameType[_0x56ae("0xb0")](table) || e[_0x56ae("0xb0")](_0x56ae("0x1a0")) > -1 || e[_0x56ae("0xb0")](
        _0x56ae("0x1a1")) > -1) if (maxTry || (maxTry = 5), totalTry >= maxTry) if (-1 == noFrameType[_0x56ae("0xb0")](
                table)) {
                var a = _0x56ae("0x1a2") + jw.getPlaylistItem()[_0x56ae("0x151")][0][_0x56ae("0x139")] + _0x56ae(
                    "0x1a3");
                $(_0x56ae("0x40"))[_0x56ae("0x59")](a)
            } else nextTry = !0;
            else totalTry++, uSwitch ? jw[_0x56ae("0x16f")](jw[_0x56ae("0x198")]()) : jw[_0x56ae("0x16f")]({
                    sources: sources[srcIdx[srcIdx.length - 1]][_0x56ae("0x151")]
                });
            else if (maxTry ? maxTry-- : maxTry = 5, totalTry >= maxTry) {
        if (table[_0x56ae("0xb0")](_0x56ae("0x2")) > -1 && (sources[currentIdx].meta[_0x56ae("0x138")] && sources[
            currentIdx][_0x56ae("0x135")][_0x56ae("0x138")][_0x56ae("0x1a4")](bckupIdx, 1), sources[currentIdx][_0x56ae(
                "0x135")][_0x56ae("0x138")] && sources[currentIdx].meta.backup2[_0x56ae("0x30")] > 0)) return void startPlay(
                sources[currentIdx]);
        nextTry = !0, uSwitch && (ignoreIdx[_0x56ae("0x116")](currentIdx), errPlay())
    } else totalTry++, uSwitch ? jw[_0x56ae("0x16f")](jw.getPlaylistItem()) : jw.load({
            sources: sources[srcIdx[srcIdx[_0x56ae("0x30")] - 1]][_0x56ae("0x151")][qualIdx]
        }); if (nextTry && !uSwitch) if (totalTry = 0, maxTry = null, nextTry = !1, srvList = !1, srcIdx[_0x56ae("0x30")] <
            sources.length) {
            for (var x, t = !1, i = 0; i < sources[_0x56ae("0x30")]; i++) if (-1 == srcIdx[_0x56ae("0xb0")](i) && -1 ==
                    bannedType[_0x56ae("0xb0")](sources[i].meta[_0x56ae("0x61")])) {
                    srcIdx[_0x56ae("0x116")](i), currentIdx = i, sources[i][_0x56ae("0x135")][_0x56ae("0x13e")] ? (x ||
                        (x = sources[i]), setCookie(sources[i].meta[_0x56ae("0x13e")]), setTimeout(function () {
                        startPlay(x), x = ""
                    }, 300)) : startPlay(sources[i]), t = !0;
                    break
                }
            t || cantPlay()
        } else cantPlay()
}
function onLevelsChanged() {}
function onCaptionsChanged() {}
function onComplete() {
    var e = $(_0x56ae("0x90"))[_0x56ae("0x39")](_0x56ae("0x84")),
        a = $(_0x56ae("0x90")).attr(_0x56ae("0x9c")) + _0x56ae("0x1a5");
    if (localStorage[_0x56ae("0x1a6")](a), "seri" == e && epArr[_0x56ae("0x30")] - 1 > parseInt(epi)) {
        var x = $(_0x56ae("0x90"))[_0x56ae("0x39")](_0x56ae("0x91"));
        allowSeek = !0, uSwitch = !1, mrload = !1, srvList = !1, nextTry = !1, havesend = !1, bannerShowed = !1, $(
            _0x56ae("0x123"))[_0x56ae("0x20")](), $(_0x56ae("0x124"))[_0x56ae("0x5b")](), epi = parseInt(epi) + 1,
            epiTitle = epArr[epi][_0x56ae("0x9f")], playLoad();
        var t = epArr[epi][_0x56ae("0x14f")],
            i = epArr[epi][_0x56ae("0x11a")],
            _ = epArr[epi][_0x56ae("0x1a7")],
            o = getChkSum($(_0x56ae("0x90"))[_0x56ae("0x39")](_0x56ae("0x9c"))),
            r = tvReq + "/?sv=" + t + _0x56ae("0x129") + i + _0x56ae("0x12a") + _ + _0x56ae("0xb8") + o + _0x56ae(
                "0x12b") + appVersion;
        actEpi = i, cordovaHTTP.setHeader(_0x56ae("0xba"), "https://mob.akubebas.com/film-seri/" + x + _0x56ae("0x12c")),
            cordovaHTTP[_0x56ae("0xbc")](!0, function () {
            cordovaHTTP[_0x56ae("0x49")](r, {}, {}, function (e) {
                var a = e[_0x56ae("0xbd")]; - 1 == a[_0x56ae("0xb0")](_0x56ae("0xbe")) && -1 == a.indexOf(_0x56ae(
                    "0xbf")) && -1 == a[_0x56ae("0xc0")]("[]") && (a = rc4(_0x56ae("0xc1"), a)), a[_0x56ae("0xb0")](
                    _0x56ae("0xc2")) > -1 && (a = a[_0x56ae("0xb0")](_0x56ae("0xbf")) > -1 || a.lastIndexOf("[]") == a[
                    _0x56ae("0x30")] - 2 ? _0x56ae("0xbf") : _0x56ae("0xbe") + (a = (a = (a = a[_0x56ae("0x26")](
                    "(adm)"))[a[_0x56ae("0x30")] - 1][_0x56ae("0x54")]())[_0x56ae("0x26")](_0x56ae("0xbe")))[a[_0x56ae(
                    "0x30")] - 1][_0x56ae("0x54")]()), beginPlay(JSON[_0x56ae("0xc4")](a))
            })
        })
    }
}
function appendLogo(e, a) {
    if (jw.getPlaylistItem()[_0x56ae("0x151")][jw[_0x56ae("0x188")]()]) var x = parseInt(jw[_0x56ae("0x198")]()[_0x56ae(
            "0x151")][jw[_0x56ae("0x188")]()][_0x56ae("0x152")]);
    else x = sources[currentIdx][_0x56ae("0x151")][0][_0x56ae("0x152")]; if ($(".jw-logo-top-left,.jw-logo-top-right")[
        _0x56ae("0x20")](), _0x56ae("0x1a8") == a) $("div.jw-controls.jw-reset")[_0x56ae("0x4d")](_0x56ae("0x1a9") +
            dom + "/images/indoxx1com.png');\"></div>");
    else if ("kata1" == a) $(_0x56ae("0x1aa"))[_0x56ae("0x4d")](
            '<div class="jw-logo jw-reset jw-logo-top-right" style="opacity: 1; margin-right: 1%; margin-top: 1.1%; width: 20%; height: 9%; min-height: 10px; min-width: 50px; background-image: url(\'' +
            imgReq + _0x56ae("0x1ab"));
    else if (_0x56ae("0x1ac") == a) e > 2 ? $("div.jw-controls.jw-reset")[_0x56ae("0x4d")](_0x56ae("0x1ad") + imgReq +
            _0x56ae("0x1ab")) : $(_0x56ae("0x1aa"))[_0x56ae("0x4d")](_0x56ae("0x1ae") + imgReq + _0x56ae("0x1ab"));
    else if ("kita1" == a) $(_0x56ae("0x1aa")).append(_0x56ae("0x1af") + imgReq + _0x56ae("0x1ab"));
    else if ("ng" == a || _0x56ae("0x1b0") == a) $(_0x56ae("0x1aa"))[_0x56ae("0x4d")](_0x56ae("0x1b1") + imgReq +
            "/images/indoxx1com.png');\"></div>");
    else if (_0x56ae("0x1b2") == a) $(_0x56ae("0x1aa"))[_0x56ae("0x4d")](
            '<div class="jw-logo jw-reset jw-logo-top-right" style="opacity: 1; margin-right: 3.8%; margin-top: 0.1%; width: 17%; height: 11%; min-height: 6px; min-width: 50px; background-image: url(\'https://img.' +
            dom + _0x56ae("0x1b3"));
    else if (_0x56ae("0x1b4") == a) $(_0x56ae("0x1aa"))[_0x56ae("0x4d")](_0x56ae("0x1b5") + imgReq + _0x56ae("0x1b6") +
            dom + _0x56ae("0x1b7"));
    else if ("na" == a || _0x56ae("0x1b8") == a) {
        var t = _0x56ae("0x1b9") + imgReq + _0x56ae("0x1ba") + (_0x56ae("0x1bb") + imgReq + _0x56ae("0x1ab"));
        $(_0x56ae("0x1aa"))[_0x56ae("0x4d")](t);
        var i = setInterval(function () {
            jw.getPosition() > 30 && (clearInterval(i), $(_0x56ae("0x1bc"))[_0x56ae("0x104")]())
        }, 1e3)
    } else "kd" == a || "ni" == a ? x <= 480 ? $(_0x56ae("0x1aa")).append(_0x56ae("0x1bd") + imgReq + _0x56ae("0x1ab")) :
            $(_0x56ae("0x1aa"))[_0x56ae("0x4d")](
            '<div class="jw-logo jw-reset jw-logo-top-left" style="opacity: 1; margin-left: 0%; margin-top: 1.1%; width: 22%; height: 13%; min-height: 28px; min-width: 115px; background-image: url(\'' +
            imgReq + _0x56ae("0x1ab")) : "nn" != a && _0x56ae("0x1be") != a && "lk" != a || (x <= 360 ? e < 2 ? $(
            _0x56ae("0x1aa"))[_0x56ae("0x4d")](
            '<div class="jw-logo jw-reset jw-logo-top-left" style="opacity: 1; margin-left: 2.5%; margin-top: 2.9%; width: 22%; height: 12%; min-height: 28px; min-width: 115px; background-image: url(\'' +
            imgReq + _0x56ae("0x1ab")) : $(_0x56ae("0x1aa"))[_0x56ae("0x4d")](_0x56ae("0x1bf") + imgReq +
            "/images/indoxx1com.png');\"></div>") : x <= 1080 && (e < 2 ? $(_0x56ae("0x1aa"))[_0x56ae("0x4d")](_0x56ae(
            "0x1c0") + imgReq + _0x56ae("0x1ab")) : $(_0x56ae("0x1aa"))[_0x56ae("0x4d")](_0x56ae("0x1c1") + imgReq +
            _0x56ae("0x1ab"))));
    $(_0x56ae("0x1c2"))[_0x56ae("0x122")]()[_0x56ae("0x83")](function () {
        $(this)[_0x56ae("0x39")](_0x56ae("0x1c3")) && window[_0x56ae("0x24")]($(this)[_0x56ae("0x39")]("data-href"),
            _0x56ae("0x25"))
    })
}
function serverList() {
    var e, a, x;
    uSwitch || (ignoreIdx = srcIdx.slice(0))[_0x56ae("0x1c4")](), $("#server-list-content")[_0x56ae("0x53")]("");
    for (var t = 0; t < sources[_0x56ae("0x30")]; t++) if (-1 == ignoreIdx[_0x56ae("0xb0")](t) && -1 == bannedType.indexOf(
            sources[t].meta[_0x56ae("0x61")])) {
            e = getServerIcon(sources[t][_0x56ae("0x135")][_0x56ae("0x61")]), a = _0x56ae("0x154"), x = "";
            for (var i = 0; i < sources[t][_0x56ae("0x151")][_0x56ae("0x30")]; i++) sources[t][_0x56ae("0x151")][i][
                        _0x56ae("0x152")] && ("hd" == sources[t][_0x56ae("0x151")][i][_0x56ae("0x152")].toLowerCase() ?
                    sources[t][_0x56ae("0x151")][i][_0x56ae("0x152")] = _0x56ae("0x153") : "sd" == sources[t][_0x56ae(
                        "0x151")][i][_0x56ae("0x152")][_0x56ae("0x55")]() && (sources[t][_0x56ae("0x151")][i][_0x56ae(
                        "0x152")] = _0x56ae("0x154")), parseInt(a) < parseInt(sources[t][_0x56ae("0x151")][i][_0x56ae(
                        "0x152")]) && -1 == (a = sources[t].sources[i].label).indexOf("p") && (a += "p"));
            parseInt(a) > 2e3 && (e = _0x56ae("0x1c5") + imgReq + _0x56ae("0x1c6")), "1" == sources[t].meta[_0x56ae(
                "0x14e")] && (e += _0x56ae("0x1c5") + imgReq + _0x56ae("0x1c7")), currentIdx == t && (x = "active"), $(
                "#server-list-content")[_0x56ae("0x4d")](_0x56ae("0x1c8") + x + _0x56ae("0x1c9") + t + '">' + e +
                _0x56ae("0x1ca") + a + _0x56ae("0x1cb"))
        }
    $(_0x56ae("0x1cc")).unbind()[_0x56ae("0x83")](function () {
        $(_0x56ae("0x1cc")).removeClass(_0x56ae("0x112")), $(this)[_0x56ae("0x10c")](_0x56ae("0x112"));
        var e = $(this)[_0x56ae("0x39")](_0x56ae("0x1cd"));
        allowSeek = !0, mrload = !1, uSwitch = !0, currentIdx = e, $(_0x56ae("0xc9")).hide(), $(".bottom-menu-logo")[
            _0x56ae("0xd2")](), $(_0x56ae("0x1ce"))[_0x56ae("0x20")](), playLoad(), sources[e][_0x56ae("0x135")][
                _0x56ae("0x13e")] && _0x56ae("0x13f") != sources[e].meta.kuki ? (setCookie(sources[e][_0x56ae("0x135")][
                _0x56ae("0x13e")]), setTimeout(function () {
            startPlay(sources[e])
        }, 300)) : startPlay(sources[e])
    })
}
function getServerIcon(e) {
    switch (e) {
    case "mp4s":
        return '<img class="server-icon" src="' + imgReq + _0x56ae("0x1cf");
    case _0x56ae("0x1d0"):
        return '<img class="server-icon" src="' + imgReq + _0x56ae("0x1d1");
    case "rapid":
        return _0x56ae("0x1d2") + imgReq + _0x56ae("0x1d3");
    case _0x56ae("0x1d4"):
        return _0x56ae("0x1d2") + imgReq + _0x56ae("0x1d5");
    case _0x56ae("0x3"):
    case _0x56ae("0x5"):
    case "facebook":
        return _0x56ae("0x1d2") + imgReq + _0x56ae("0x1d6");
    case _0x56ae("0x2"):
    case _0x56ae("0x0"):
    case _0x56ae("0x1"):
        return _0x56ae("0x1d2") + imgReq + _0x56ae("0x1d7")
    }
}
function cantPlay() {
    $(_0x56ae("0x1d8"))[_0x56ae("0x20")](), $(_0x56ae("0x90"))[_0x56ae("0x39")]("data-lemon") || $(_0x56ae("0x90"))[
        _0x56ae("0x39")]("data-mp4s") ? $(_0x56ae("0x1d9")).height(250)[_0x56ae("0x34")](_0x56ae("0x1da")) : $(
        "#vid-container, #vid").height(250)[_0x56ae("0x34")](
        '<div id="infosv" style="position:absolute;top:50%;transform: translateY(-50%);color:#f8f8f8;width:100%;height:100%;z-index:9;background:#000;"><div style="display:inline-block;position:relative;top:50%;left:50%;transform:translate(-48%,-50%);padding:10px;"><img src="' +
        imgReq + _0x56ae("0x1db")), _0x56ae("0x8f") == $(_0x56ae("0x90"))[_0x56ae("0x39")](_0x56ae("0x84")) && ($(
        ".bottom-menu-logo,.bottom-menu")[_0x56ae("0x104")](), $("#bottom-menu-eps").css(_0x56ae("0x193"), _0x56ae(
        "0x14d"))[_0x56ae("0xd2")]())
}
function errPlay() {
    $(_0x56ae("0x1d8"))[_0x56ae("0x20")](), $(_0x56ae("0x1d9"))[_0x56ae("0x3e")](250), $(_0x56ae("0x40"))[_0x56ae(
        "0x34")](_0x56ae("0x1dc") + imgReq +
        '/images/err-monster.png" width="140px" height="auto" style="float: left;position: relative;top: -15px;right: 5px;"><div style="padding:5px;font-size:1.2em;font-weight:bold;">Gagal Memutar Film!</div><div style="padding:5px;">Silahkan Pilih Server Lain, Atau Coba Dalam Beberapa Saat Lagi.</div><div style="clear:both;"></div></div></div>')
}
function playLoad() {
    $(_0x56ae("0x1dd"))[_0x56ae("0x20")](), $("#vid")[_0x56ae("0x3e")]($(_0x56ae("0x40"))[_0x56ae("0x3e")]()), $(
        _0x56ae("0x40")).prepend(_0x56ae("0x1de") + imgReq + _0x56ae("0x1df"))
}
function downloadSub() {
    if ("1" != hs) {
        var e = jw[_0x56ae("0x1e0")]();
        if (0 != e) {
            var a = jw.getCaptionsList(),
                x = getTitle(),
                t = a[e].id,
                i = a[e][_0x56ae("0x152")][_0x56ae("0x26")](" ")[_0x56ae("0x1d")]("-");
            x += "-" + i;
            var _ = cordova[_0x56ae("0x1e1")][_0x56ae("0x1e2")];
            _[_0x56ae("0x1e3")](_[_0x56ae("0x1e4")], function (e) {
                e[_0x56ae("0x1e3")] ? beginDownloadSub(t, x) : _[_0x56ae("0x1e5")](_[_0x56ae("0x1e4")], function (e) {
                    beginDownloadSub(t, x)
                }, function () {})
            })
        } else $[_0x56ae("0x1e6")](_0x56ae("0x1e7"), 8e3)
    } else $[_0x56ae("0x1e6")](_0x56ae("0x1e8"), 8e3)
}
function beginDownloadSub(e, a) {
    var x = new FileTransfer,
        t = _0x56ae("0x1e9") + a + _0x56ae("0x1ea");
    window[_0x56ae("0x1eb")](t, function () {
        $[_0x56ae("0x1e6")](_0x56ae("0x1ec"), 8e3), x = ""
    }, function () {
        x.download(e, t, function (e) {
            x = "", $.alert(_0x56ae("0x1ed"))
        }, function (e) {
            x = "", $.tips("Download Gagal, Silahkan Coba Kembali Atau Pilih Subtitle Lain!", 4e3)
        }, !0, {
            headers: {
                Authorization: "Basic dGVzdHVzZXJuYW1lOnRlc3RwYXNzd29yZA=="
            }
        })
    })
}
function downloadMovie() {
    var e = jw[_0x56ae("0x198")]()[_0x56ae("0x151")][jw[_0x56ae("0x188")]()].file,
        a = (jw[_0x56ae("0x198")]()[_0x56ae("0x151")][jw[_0x56ae("0x188")]()][_0x56ae("0x152")], getTitle());
    if (e.substr(-4), -1 != bannedType[_0x56ae("0xb0")](table) || $(_0x56ae("0x170"))[_0x56ae("0x30")]) $[_0x56ae(
            "0x1e6")](_0x56ae("0x1ee"));
    else {
        var x = cordova[_0x56ae("0x1e1")][_0x56ae("0x1e2")];
        x.hasPermission(x[_0x56ae("0x1e4")], function (t) {
            t.hasPermission ? beginDownload(e, a) : x[_0x56ae("0x1e5")](x[_0x56ae("0x1e4")], function (x) {
                beginDownload(e, a)
            }, function () {})
        })
    }
}
function beginDownload(e, a) {
    var x = new FileTransfer,
        t = showDownloadProgress();
    $(_0x56ae("0x1ef") + t)[_0x56ae("0x59")]("Batal")[_0x56ae("0x83")](function () {
        $(_0x56ae("0x1f0") + t).remove();
        var e = $(_0x56ae("0x1f1"))[_0x56ae("0x30")];
        $(_0x56ae("0x1f2")).html(_0x56ae("0x1f3") + e + ")"), $(_0x56ae("0x1f1"))[_0x56ae("0x30")] || $(_0x56ae("0x1f4"))[
            _0x56ae("0x20")](), "" != x && x.abort()
    }), $(_0x56ae("0x1f5") + t)[_0x56ae("0x59")](a);
    var i = _0x56ae("0x1e9") + a + _0x56ae("0x155");
    window[_0x56ae("0x1eb")](i, function () {
        $.tips(_0x56ae("0x1f6"), 8e3), $("#download-progress-perc" + t)[_0x56ae("0x7f")]({
            width: _0x56ae("0x14d"),
            background: _0x56ae("0x1f7")
        }), $("#download-progress-close" + t).html(_0x56ae("0x1f8")), x = ""
    }, function () {
        var _, o;
        x.onprogress = function (e) {
            if (e.lengthComputable) {
                parseInt(e[_0x56ae("0x1f9")] / 1e9) > 0 ? o = parseFloat(e[_0x56ae("0x1f9")] / 1e9).toFixed(1) +
                    _0x56ae("0x1fa") : parseInt(e[_0x56ae("0x1f9")] / 1e6) > 0 && (o = parseFloat(e[_0x56ae("0x1f9")] /
                    1e6)[_0x56ae("0x18e")](1) + _0x56ae("0x1fb")), e[_0x56ae("0x1fc")] < 1e6 ? _ = parseInt(e[_0x56ae(
                    "0x1fc")] / 1e3) + _0x56ae("0x1fd") : e[_0x56ae("0x1fc")] < 1e9 ? _ = parseFloat(e[_0x56ae("0x1fc")] /
                    1e6)[_0x56ae("0x18e")](1) + _0x56ae("0x1fb") : e[_0x56ae("0x1fc")] >= 1e9 && (_ = parseFloat(e[
                    _0x56ae("0x1fc")] / 1e9)[_0x56ae("0x18e")](1) + "GB"), $(_0x56ae("0x1fe") + t).html(_), $(_0x56ae(
                    "0x1ff") + t).html(o);
                var a = Math.floor(e[_0x56ae("0x1fc")] / e[_0x56ae("0x1f9")] * 100);
                $(_0x56ae("0x200") + t)[_0x56ae("0x7f")](_0x56ae("0x193"), a + "%")
            }
        }, x[_0x56ae("0x201")](encodeURI(e), i, function (e) {
            $("#download-progress-perc" + t)[_0x56ae("0x7f")](_0x56ae("0x80"), _0x56ae("0x1f7")), $(
                "#download-progress-close" + t)[_0x56ae("0x59")](_0x56ae("0x1f8")), x = "", mediaRefresh[_0x56ae(
                "0x202")](e.toURL(), function (e) {
                $.alert(a + _0x56ae("0x203"))
            }, function (e) {
                $[_0x56ae("0x1e6")](_0x56ae("0x204") + e)
            })
        }, function (e) {
            $(_0x56ae("0x200") + t)[_0x56ae("0x7f")]({
                width: _0x56ae("0x14d"),
                background: "#eeaaaa"
            }), $(_0x56ae("0x1f5") + t).html(_0x56ae("0x205")), $(_0x56ae("0x1ef") + t)[_0x56ae("0x59")]("Tutup"), x =
                ""
        }, !0, {
            headers: {
                Authorization: "Basic dGVzdHVzZXJuYW1lOnRlc3RwYXNzd29yZA=="
            }
        })
    })
}
function showDownloadProgress() {
    var e = (new Date).getTime()[_0x56ae("0x19b")]();
    $("#download-progress-content")[_0x56ae("0x30")] ? $(_0x56ae("0x206"))[_0x56ae("0x34")](
        '<div class="download-progress" id="download-progress' + e +
        '"><div class="download-progress-title" id="download-progress-title' + e + _0x56ae("0x207") + e + _0x56ae(
        "0x208") + e + _0x56ae("0x209") + e + _0x56ae("0x20a") + e + _0x56ae("0x20b")) : ($(_0x56ae("0x33"))[_0x56ae(
        "0x34")](
        '<div id="download-progress-content"><div id="download-progress-toggle"><div id="download-progress-total">Download (1)</div><div id="download-progress-icon">-</div><div style="clear:both;"></div></div><div id="download-progress-list"><div class="download-progress" id="download-progress' +
        e + _0x56ae("0x20c") + e + _0x56ae("0x207") + e + _0x56ae("0x208") + e + _0x56ae("0x209") + e + _0x56ae("0x20a") +
        e + _0x56ae("0x20d")), $(_0x56ae("0x20e"))[_0x56ae("0x83")](function () {
        $(_0x56ae("0x206")).is(_0x56ae("0x20f")) ? ($(_0x56ae("0x20e"))[_0x56ae("0x7f")]({
            "border-bottom": _0x56ae("0x210"),
            "padding-bottom": _0x56ae("0x211")
        }), $(_0x56ae("0x206"))[_0x56ae("0xde")](), $(_0x56ae("0x212"))[_0x56ae("0x59")]("-")[_0x56ae("0x7f")]({
            "font-size": _0x56ae("0x213"),
            top: _0x56ae("0x214")
        })) : ($(_0x56ae("0x20e"))[_0x56ae("0x7f")]({
            border: "0",
            "padding-bottom": "0"
        }), $(_0x56ae("0x206"))[_0x56ae("0x104")](), $(_0x56ae("0x212")).html("+")[_0x56ae("0x7f")]({
            "font-size": _0x56ae("0x215"),
            top: _0x56ae("0x216")
        }))
    }));
    var a = $(_0x56ae("0x1f1"))[_0x56ae("0x30")];
    return $(_0x56ae("0x1f2"))[_0x56ae("0x59")]("Download (" + a + ")"), e
}
function setCookie(e) {
    window[_0x56ae("0x217")].setCookie(_0x56ae("0x218"), _0x56ae("0x219"), e, function () {
        console[_0x56ae("0x2d")](_0x56ae("0x21a"))
    }, function (e) {
        $[_0x56ae("0x1e6")](_0x56ae("0x21b") + e)
    })
}
function removePage() {
    freeze = !0, totalTry = 0, maxTry = null, mrload = !1, nextTry = !1, srvList = !1, havesend = !1, bannerShowed = !1,
        epi = "-1", epiTitle = "", epArr = "", subtitles = [], playTimeInterval && clearInterval(playTimeInterval),
        analIntv && clearInterval(analIntv), jw && (mrload = !1, uSwitch = !1), 1 == $(_0x56ae("0x21c")).length ? (
        freeze = !1, navigator.home[_0x56ae("0x2c")](function () {
        console[_0x56ae("0x2d")](_0x56ae("0x2e"))
    }, function () {
        console[_0x56ae("0x2d")](_0x56ae("0x21d"))
    })) : ($(_0x56ae("0x21c")).last()[_0x56ae("0x5b")](150), setTimeout(function () {
        $(_0x56ae("0x21c"))[_0x56ae("0x21e")]()[_0x56ae("0x20")](), freeze = !1, controller && !$("#movies-page-list")[
            _0x56ae("0x30")] && (controller[_0x56ae("0x134")](!0), controller = null, scene = null)
    }, 150))
}
function loadContainer(e) {
    var a;
    "1" == e ? (freeze = !0, $("#cdv-loader-content")[_0x56ae("0x30")] && $(_0x56ae("0x21f"))[_0x56ae("0x20")](), $(
        "body").prepend(_0x56ae("0x220")), $("#cdv-loader-content").css({
        width: $("body")[_0x56ae("0x193")](),
        height: window[_0x56ae("0x221")],
        top: $(_0x56ae("0x33")).scrollTop() + "px"
    }), a = setInterval(function () {
        $(_0x56ae("0x21f"))[_0x56ae("0x7f")]({
            width: $("body")[_0x56ae("0x193")](),
            height: window.innerHeight,
            top: $(_0x56ae("0x33"))[_0x56ae("0xd0")]() + "px"
        })
    }, 500)) : (clearInterval(a), $(_0x56ae("0x21f"))[_0x56ae("0x20")](), freeze = !1)
}
function getTitle() {
    var e = jw[_0x56ae("0x198")]()[_0x56ae("0x151")][jw[_0x56ae("0x188")]()][_0x56ae("0x152")];
    e = parseInt(e) < 720 ? _0x56ae("0x222") + e : _0x56ae("0x223") + e;
    var a = $(_0x56ae("0x9e"))[_0x56ae("0x53")]();
    a = (a = (a = a.replace(/[^a-z0-9]+/gi, " ")[_0x56ae("0x54")]())[_0x56ae("0xed")]("  ", " "))[_0x56ae("0xed")](" ",
        "-");
    var x = "";
    return epiTitle && (x = "-" + epi[_0x56ae("0x54")]()), _0x56ae("0x224") + (a = a + "-" + e + x[_0x56ae("0x54")]())[
        _0x56ae("0x54")]() + "]"
}
var Base64 = {
    _keyStr: "ZYX10+/PONM765LKJIAzyTSRQGxwvuHWVFEDUCBtsrqdcba9843ponmlkjihgfe2",
    encode: function (e) {
        var a, x, t, i, _, o, r, n = "",
            s = 0;
        for (e = Base64[_0x56ae("0x225")](e); s < e[_0x56ae("0x30")];) i = (a = e[_0x56ae("0x226")](s++)) >> 2, _ = (3 &
                a) << 4 | (x = e[_0x56ae("0x226")](s++)) >> 4, o = (15 & x) << 2 | (t = e[_0x56ae("0x226")](s++)) >> 6,
                r = 63 & t, isNaN(x) ? o = r = 64 : isNaN(t) && (r = 64), n = n + this[_0x56ae("0x227")].charAt(i) +
                this[_0x56ae("0x227")].charAt(_) + this[_0x56ae("0x227")][_0x56ae("0x228")](o) + this._keyStr[_0x56ae(
                "0x228")](r);
        return n
    },
    decode: function (e) {
        var a, x, t, i, _, o, r = "",
            n = 0;
        for (e = e[_0x56ae("0xed")](/[^A-Za-z0-9+\/=]/g, ""); n < e[_0x56ae("0x30")];) a = this._keyStr[_0x56ae("0xb0")](
                e[_0x56ae("0x228")](n++)) << 2 | (i = this._keyStr[_0x56ae("0xb0")](e[_0x56ae("0x228")](n++))) >> 4, x =
                (15 & i) << 4 | (_ = this[_0x56ae("0x227")][_0x56ae("0xb0")](e[_0x56ae("0x228")](n++))) >> 2, t = (3 &
                _) << 6 | (o = this[_0x56ae("0x227")].indexOf(e[_0x56ae("0x228")](n++))), r += String[_0x56ae("0x229")](
                a), 64 != _ && (r += String[_0x56ae("0x229")](x)), 64 != o && (r += String[_0x56ae("0x229")](t));
        return Base64[_0x56ae("0x22a")](r)
    },
    _utf8_encode: function (e) {
        e = e[_0x56ae("0xed")](/rn/g, "n");
        for (var a = "", x = 0; x < e[_0x56ae("0x30")]; x++) {
            var t = e[_0x56ae("0x226")](x);
            t < 128 ? a += String[_0x56ae("0x229")](t) : t > 127 && t < 2048 ? (a += String[_0x56ae("0x229")](t >> 6 |
                192), a += String[_0x56ae("0x229")](63 & t | 128)) : (a += String[_0x56ae("0x229")](t >> 12 | 224), a +=
                String[_0x56ae("0x229")](t >> 6 & 63 | 128), a += String.fromCharCode(63 & t | 128))
        }
        return a
    },
    _utf8_decode: function (e) {
        for (var a = "", x = 0, t = c1 = c2 = 0; x < e[_0x56ae("0x30")];)(t = e.charCodeAt(x)) < 128 ? (a += String[
                _0x56ae("0x229")](t), x++) : t > 191 && t < 224 ? (c2 = e[_0x56ae("0x226")](x + 1), a += String[_0x56ae(
                "0x229")]((31 & t) << 6 | 63 & c2), x += 2) : (c2 = e.charCodeAt(x + 1), c3 = e[_0x56ae("0x226")](x + 2),
                a += String[_0x56ae("0x229")]((15 & t) << 12 | (63 & c2) << 6 | 63 & c3), x += 3);
        return a
    }
};

function rc4(e, a) {
    var x = (a = Base64[_0x56ae("0x22b")](a)).lastIndexOf("]");
    return a[_0x56ae("0x22c")](0, x + 1)
}
function uniqid() {
    var e, a = a || "",
        x = x || !1;
    return this.seed = function (e, a) {
        return a < (e = parseInt(e, 10)[_0x56ae("0x19b")](16))[_0x56ae("0x30")] ? e[_0x56ae("0x22d")](e[_0x56ae("0x30")] -
            a) : a > e[_0x56ae("0x30")] ? new Array(a - e.length + 1)[_0x56ae("0x1d")]("0") + e : e
    }, e = a + this[_0x56ae("0x22e")](parseInt((new Date)[_0x56ae("0x4b")]() / 1e3, 10), 8) + this[_0x56ae("0x22e")](
        Math[_0x56ae("0x157")](123456789 * Math.random()) + 1, 5), x && (e += (10 * Math[_0x56ae("0x189")]())[_0x56ae(
        "0x18e")](8)[_0x56ae("0x19b")]()), e
}
function lazy() {
    $(_0x56ae("0x22f"))[_0x56ae("0x51")](function () {
        var e = $(this)[_0x56ae("0x39")](_0x56ae("0x230"));
        $(this)[_0x56ae("0x7f")](_0x56ae("0x231"), _0x56ae("0x81") + e + "')")
    })
}
function getChkSum(e) {
    var a = calcTime("+7"),
        x = a[_0x56ae("0x232")]();
    x %= tsdiv;
    var t = 1e3 * a[_0x56ae("0x233")](),
        i = new Date(a - 6e4 * x - t),
        _ = Math[_0x56ae("0x157")](i[_0x56ae("0x4b")]() / 1e3);
    return crc32(btoa(_ + e) + _ + e + crc32(e + _))
}
function calcTime(e) {
    var a = new Date,
        x = a[_0x56ae("0x4b")]() + 6e4 * a[_0x56ae("0x234")](),
        t = new Date(x + 36e5 * e);
    return (t = t[_0x56ae("0x19b")]()[_0x56ae("0x26")](_0x56ae("0x235")))[1] = _0x56ae("0x236"), new Date(t[_0x56ae(
        "0x1d")](_0x56ae("0x235")))
}
function crc32(e) {
    for (var a = 0, x = 0, t = 0, i = e[_0x56ae("0x30")]; t < i; t++) t % 2 == 0 ? a += e[_0x56ae("0x226")](t) : x += e[
            _0x56ae("0x226")](t);
    return a * (a + x) * Math.abs(a - x)
}
String[_0x56ae("0x237")][_0x56ae("0xf0")] = function () {
    return this[_0x56ae("0x55")]()[_0x56ae("0xed")](/(^([a-zA-Z\p{M}]))|([ -][a-zA-Z\p{M}])/g, function (e) {
        return e[_0x56ae("0x238")]()
    })
};