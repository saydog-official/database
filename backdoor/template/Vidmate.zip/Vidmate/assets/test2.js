

var cc;
function vid_mate_check()
{	
	if(cc==null)
	{
	cc=1;
	}
	cc++;
	
	log(cc);
	
	
}

